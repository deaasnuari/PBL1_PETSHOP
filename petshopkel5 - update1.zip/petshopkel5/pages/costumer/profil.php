<?php
//nama file: profil .php
//deskripsi: untuk bagian profil
//dibuat oleh: front-end hamdan azmi[3312411004] christian mrcelino[3312411008]
//dibuat tgl: 9/12-28/12

include '../../config/koneksi.php';
session_start();

$id  = $_SESSION["id"];

$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//    $type = strtolower($_POST['type']); 
//    $newValue = $_POST['value'];

//    try {
//        $query = "";
//        if ($type === 'username') {
//            $query = "UPDATE users SET username = :value WHERE id = :id";
//        } elseif ($type === 'email') {
//            $query = "UPDATE users SET email = :value WHERE id = :id";
//        } elseif ($type === 'no_hp') {
//            $query = "UPDATE users SET no_hp = :value WHERE id = :id";
//        } elseif ($type === 'alamat') {
//            $query = "UPDATE users SET alamat = :value WHERE id = :id";
//        } elseif ($type === 'password') {
//            $hashedPassword = password_hash($newValue, PASSWORD_DEFAULT);
//            $query = "UPDATE users SET password = :value WHERE id = :id";
//        }

//        if ($query !== "") {
//            $updateStmt = $conn->prepare($query);
//            if ($type === 'password') {
//                // Jika type adalah password, gunakan hashedPassword
//                $updateStmt->bindParam(':value', $hashedPassword, PDO::PARAM_STR);
//            } else {
//                // Untuk jenis lainnya, gunakan newValue
//                $updateStmt->bindParam(':value', $newValue, PDO::PARAM_STR);
//            }
//            $updateStmt->bindParam(':id', $id, PDO::PARAM_INT);
//            $updateStmt->execute();
//        }

//        echo json_encode(["success" => true]);
//    } catch (Exception $e) {
//        echo json_encode(["success" => false, "error" => $e->getMessage()]);
//    }
//    exit;
// }

?>





<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login - MiaWoof PETSHOP</title>
   <link rel="icon" href="../../assets/images/miawoof-logo.jpg" type="image/x-icon">
   <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
   <link
      href="https://fonts.googleapis.com/css2?family=Inria+Sans:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Irish+Grover&display=swap"
      rel="stylesheet">
   <link rel="stylesheet" href="../../assets/css/costumer/template.css">
   <link rel="stylesheet" href="../../assets/css/costumer/profil.css">
</head>



<body>
   <div id="header-container">
      <script>
            fetch('../../layout/costumer/costumer_header.html')
               .then(response => response.text())
               .then(data => {
                  document.getElementById('header-container').innerHTML = data;
                  const openSidebarElements = document.querySelectorAll(".openSidebar");
                  const closeSidebar = document.getElementById("closeSidebar");
                  Array.from(openSidebarElements).forEach(element => {
                     element.addEventListener("click", sidebarToggle);
                  });
                  closeSidebar.addEventListener("click", sidebarToggle);
               })
               .catch(error => console.error('Error loading header:', error));
         </script>
   </div>


   <main>




      <div class="profil-container">
      <?php foreach($result as $duser) : ?>
         <div class="profil-head">
            <h1>Profil</h1>
            <h2>
               <svg xmlns="http://www.w3.org/2000/svg" width="32" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                  stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
               </svg>
               <span>
                  <?= $duser["username"]; ?>
               </span>
            </h2>
         </div>
         <div class="profil-area">
            <section>
               <figure>
                  <img src="../../assets/icons/user.svg" width="100" alt="">
               </figure>
               <button onclick="location.href='comingsoon.html'">Pilih Foto</button>
               <button  <?=   $duser["password"];   ?>
                         data-type="password" data-value="<?=   $duser["password"];   ?>"
                           class="ubah" id="password">Ubah Password</button>
            </section>
            <section>
               <h3>Biodata Saya</h3><br>
               <table border="0">
                  <tr>
                     <td>Nama</td>
                     <td>
                        <?=   $duser["username"];   ?>
                        <button data-type="username" data-value="<?=   $duser["username"];   ?>"
                           class="ubah" id="username">ubah</button>
                     </td>
                  </tr>
                  <tr>
                     <td>Email</td>
                     <td>
                     <?=   $duser["email"];   ?>
                        <button data-type="Email" data-value="<?=   $duser["email"];   ?>"
                           class="ubah" id="email">ubah</button>
                     </td>
                  </tr>
                  <tr>
                     <td>No.hanphone</td>
                     <td>
                     <?=   $duser["no_hp"];   ?>
                       <button data-type="No. Handphone" data-value="<?=   $duser["no_hp"];   ?>"
                           class="ubah" id="kontak">ubah</button>
                     </td>
                  </tr>
                  <tr>
                     <td>Alamat</td>
                     <td>
                     <?=   $duser["alamat"];   ?>
                        <button data-type="alamat" data-value="<?=   $duser["alamat"];   ?>"
                           class="ubah" id="alamat">ubah</button>
                     </td>
                  </tr>
               </table>
            </section>
         </div>
      <?php endforeach; ?>
      </div>


      <!-- END MAIN-->
   </main>


   

   <div class="pop-up-container" id="popUp" style="display: none;">
    <form id="popUpForm" class="pop-up" method="POST">
        <div class="pop-up-head">
            <h3 id="popUpTitle">Ganti Data</h3>
            <img id="clsPopUp" src="../../assets/icons/x.svg" alt="">
        </div>
        <div class="input-group">
            <label id="inputLabel">Data</label>
            <input type="text" id="inputData" name="value" autocomplete="off">
            <input type="hidden" id="inputType" name="type">
        </div>
        <button type="submit">Simpan</button>
    </form>
</div>


   <div id="footer-container">
      <script>
         fetch('../../layout/costumer/costumer_footer.html')
            .then(response => response.text())
            .then(data => {
               document.getElementById('footer-container').innerHTML = data;
            })
            .catch(error => console.error('Error loading header:', error));
      </script>
   </div>

   <script src="../../assets/js/script.js"></script>


   <script>
      const popUp = document.getElementById('popUp');
      const popUpTitle = document.getElementById('popUpTitle');
      const inputLabel = document.getElementById('inputLabel');
      const inputData = document.getElementById('inputData');
      const clsPopUp = document.getElementById('clsPopUp');
      const popUpForm = document.getElementById('popUpForm');

      document.querySelectorAll('.ubah').forEach(button => {
    button.addEventListener('click', event => {
        event.preventDefault();

        const value = button.dataset.value;
        const type = button.dataset.type;

        // Update popup form fields
        document.getElementById('popUpTitle').innerText = `Ganti ${type}`;
        document.getElementById('inputLabel').innerText = type;
        document.getElementById('inputData').value = value;
        document.getElementById('inputType').value = type;

        document.getElementById('popUp').style.display = 'flex';
    });
});

document.getElementById('clsPopUp').addEventListener('click', () => {
    document.getElementById('popUp').style.display = 'none';
});

document.getElementById('popUpForm').addEventListener('submit', event => {
    event.preventDefault();

    const formData = new FormData(event.target);

    // Send data to the backend using fetch
    fetch('profil.php', {
        method: 'POST',
        body: formData,
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Data berhasil diperbarui!');
                location.reload(); // Refresh halaman setelah berhasil
            } else {
                alert('Terjadi kesalahan saat memperbarui data!');
            }
        })
        .catch(error => console.error('Error:', error));
});


      clsPopUp.addEventListener('click', () => {
         popUp.style.display = 'none';
      });



      popUpForm.addEventListener('submit', event => {
         event.preventDefault();
         const newValue = inputData.value;
         const type = inputLabel.innerText.toLowerCase();
         // lakukan pengiriman ke PHP disini nanti yakk
         console.log(`Mengubah ${type} menjadi: ${newValue}`);
         popUp.style.display = 'none';
      });
   </script>
</body>

</html>