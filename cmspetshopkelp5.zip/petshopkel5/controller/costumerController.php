<?php 
//nama file: [costumerController.php]
//deskripsi: [file ini digunakan untuk menangani berbagai operasi terkait pesanan,
// booking, dan penghapusan data]
//dibuat oleh: [Christian Marcelino]] - NIM [3312411008]
//tanggal: 28-12-2024


include "../config/koneksi.php";
session_start();

if (isset($_POST['pesanan'])) {
    // print_r($_POST);
    $id_pembeli = $_POST['id_pembeli'];
    $id_produk = $_POST['id_produk'];
    $jumlah = $_POST['jumlah'];
    $total = $_POST['total'];
    $status = "menunggu pembayaran";
    try {
        $conn->beginTransaction();

        $sql = "INSERT INTO pesanan(id_produk, id_pembeli, jumlah, total, status) VALUES(:id_produk, :id_pembeli, :jumlah, :total, :status)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_produk', $id_produk, PDO::PARAM_INT);
        $stmt->bindParam(':id_pembeli', $id_pembeli, PDO::PARAM_INT);
        $stmt->bindParam(':jumlah', $jumlah, PDO::PARAM_INT);
        $stmt->bindParam(':total', $total, PDO::PARAM_INT);
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);

        if ($stmt->execute()) {
            $sqlUpdate = "UPDATE produk SET stock = stock - :stock WHERE id_produk = :id_produk";
            $stmtUpdate = $conn->prepare($sqlUpdate);

            $stmtUpdate->bindParam(':stock', $jumlah, PDO::PARAM_INT);
            $stmtUpdate->bindParam(':id_produk', $id_produk, PDO::PARAM_INT);

            if ($stmtUpdate->execute()) {
                $conn->commit();
                $_SESSION['pesanan_berhasil'] = "Pesanan berhasil dibuat";
            } else {
                $conn->rollBack();
                $_SESSION['pesanan_gagal'] = "Gagal mengurangi jumlah produk.";
            }
        } else {
            $_SESSION['pesanan_gagal'] = "Pesanan gagal dibuat.";
        }

        header("Location: ../pages/costumer/statuspembayaran.php");
        exit();

    } catch (PDOException $e) {
        $conn->rollBack();
        echo "Error: " . $e->getMessage();
    }
}

if (isset($_GET['hapus_pesanan'])) {
    echo $_GET['hapus_pesanan'];
    $id_pesanan = $_GET['hapus_pesanan'];

    try {
        $sql = "DELETE FROM pesanan WHERE id_pesanan = $id_pesanan";
        $stmt = $conn->prepare($sql);

        if ($stmt->execute()) {
            $_SESSION['hapus_berhasil'] = "Pesanan $id_pesanan berhasil dihapus";
        } else {
            $_SESSION['hapus_gagal'] = "Pesanan $id_pesanan gagal dihapus";
        }
        
        header("Location: ../pages/costumer/statuspembayaran.php");
        exit();

   } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
   }
}

if (isset($_POST['booking'])) {
    // var_dump($_POST);

    $id_costumer = $_POST['id_costumer'];
    $tgl = $_POST['tgl'];
    $bulan = $_POST['bulan'];
    $waktu = $_POST['waktu'];
    $hewan = $_POST['hewan'];
    $kategori_paket = $_POST['paket_kategori'];
    $status = "menunggu konfirmasi";

    try {
        $conn->beginTransaction();
    
        $sql = "SELECT id_paket FROM paket_grooming WHERE jenis_hewan = :hewan AND nama_paket = :kategori_paket";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':hewan', $hewan, PDO::PARAM_STR);
        $stmt->bindParam(':kategori_paket', $kategori_paket, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
        if ($result) {
            $id_paket = $result['id_paket'];
    
            $sqlInsert = "INSERT INTO booking (id_paket, id_costumer, tgl, bulan, waktu, status) VALUES (:id_paket, :id_costumer, :tgl, :bulan, :waktu, :status)";
            $stmtInsert = $conn->prepare($sqlInsert);
    
            $stmtInsert->bindParam(':id_paket', $id_paket, PDO::PARAM_INT);
            $stmtInsert->bindParam(':id_costumer', $id_costumer, PDO::PARAM_INT);
            $stmtInsert->bindParam(':tgl', $tgl, PDO::PARAM_STR);
            $stmtInsert->bindParam(':bulan', $bulan, PDO::PARAM_STR);
            $stmtInsert->bindParam(':waktu', $waktu, PDO::PARAM_STR);
            $stmtInsert->bindParam(':status', $status, PDO::PARAM_STR);
    
            if ($stmtInsert->execute()) {
                $conn->commit();
                echo "Booking berhasil dibuat.";
                $_SESSION['booking_berhasil'] = "booking berhasil dibuat";

            } else {
                $conn->rollBack();
                echo "Gagal membuat booking.";
                $_SESSION['booking_gagal'] = "booking gagal dibuat";
            }

            header("Location: ../pages/costumer/bookinglist.php");
            exit();
    

        } else {
            echo "Paket grooming tidak ditemukan.";
        }
    } catch (PDOException $e) {
        $conn->rollBack();
        echo "Error: " . $e->getMessage();
    }
}

if (isset($_GET['hapusBooking'])) {
    // echo $_GET['hapus_pesanan'];
    $id_booking = "000".$_GET['hapusBooking'];

    try {
        $sql = "DELETE FROM booking WHERE id_booking = $id_booking";
        $stmt = $conn->prepare($sql);

        if ($stmt->execute()) {
            $_SESSION['hapus_berhasil'] = "booking $id_booking dibatalkan";
        } else {
            $_SESSION['hapus_gagal'] = "gagal";
        }
        
        header("Location: ../pages/costumer/bookinglist.php");
        exit();

   } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
   }
}



?>