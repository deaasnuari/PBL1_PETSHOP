<?php 
//nama file: [admincontrroller.php]
//deskripsi: [file ini digunakan untuk mengelola dan mengatur logika aplikasi seperti,
//menambahkan, mengubah, dan menghapus data]
//dibuat oleh: [dea asnuari] - NIM [3312411001]
//tanggal: 28-12-2024


include "../config/koneksi.php";
session_start();

//ini tambah produk
if(isset($_POST['tambah_produk'])) {
    // print_r($_POST);
    // die();
    $nama_produk = $_POST['nama_produk'];
    $kategori = $_POST['kategori'];
    $harga = $_POST['harga'];
    $gambar = $_FILES['gambar_produk']['name'];
    $tgl_produksi = $_POST['tgl_produksi'];
    $tgl_expired = $_POST['tgl_expired'];
    $nama_produk = $_POST['nama_produk'];
    $stock = $_POST['stock'];

    $path = "../assets/product_item/" . $gambar;
    $tmp_file = $_FILES['gambar_produk']['tmp_name'];
    move_uploaded_file($tmp_file, $path);

    if (is_uploaded_file($tmp_file)) {
        if (!move_uploaded_file($tmp_file, $path)) {
            echo "ERROR - gagal mengunggah file.";
            die();
        }
    }

    $sql = "INSERT INTO produk VALUES(null, :nama, :kategori, :stock, :harga, :gambar, :tgl_dibuat, :tgl_expired)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':nama', $nama_produk, PDO::PARAM_STR);
    $stmt->bindParam(':kategori', $kategori, PDO::PARAM_STR);
    $stmt->bindParam(':stock', $stock, PDO::PARAM_INT);
    $stmt->bindParam(':harga', $harga, PDO::PARAM_INT);
    $stmt->bindParam(':gambar', $gambar, PDO::PARAM_STR);
    $stmt->bindParam(':tgl_dibuat', $tgl_produksi, PDO::PARAM_STR);
    $stmt->bindParam(':tgl_expired', $tgl_expired, PDO::PARAM_STR);

    if ($stmt->execute()) {
        $_SESSION['success'] = "produk berhasil ditambahkan";
    } else {
        echo "ERROR - gagal";
        $_SESSION['failed'] = "Terjadi kesalahan Produk gagal dibuat.";
    }

    header("Location: ../pages/admin/product_dashboard.php");
    exit();


} elseif (isset($_POST['tambah_user'])) {
    // print_r($_POST);
    // die();
    $nama_user = $_POST['full_name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $telepon = $_POST['no_hp'];
    $alamat = $_POST['alamat'];
    $role = "costumer";
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, password, full_name, email, no_hp, alamat, role) 
            VALUES (:username, :password, :full_name, :email, :no_hp, :alamat, :role)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':full_name', $nama_user, PDO::PARAM_STR);
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->bindParam(':password', $hashedPassword, PDO::PARAM_STR); // Changed to PDO::PARAM_STR
    $stmt->bindParam(':email', $email, PDO::PARAM_STR); // Changed to PDO::PARAM_STR
    $stmt->bindParam(':no_hp', $telepon, PDO::PARAM_STR);
    $stmt->bindParam(':alamat', $alamat, PDO::PARAM_STR);
    $stmt->bindParam(':role', $role, PDO::PARAM_STR);

    if ($stmt->execute()) {
        $_SESSION['success'] = "User  berhasil ditambahkan";
    } else {
        // Log the error for debugging
        $errorInfo = $stmt->errorInfo();
        echo "ERROR - gagal: " . $errorInfo[2]; // Display the error message
        $_SESSION['failed'] = "Terjadi kesalahan User gagal dibuat.";
    }

    header("Location: ../pages/admin/user_dashboard.php");
    exit();


} elseif(isset($_POST['tambah_paket'])) {
    // print_r($_POST);
    // die();
    // $id_paket = $_POST['id_paket'];
    $nama_paket = $_POST['nama_paket'];
    $harga = $_POST['harga'];
    $keterangan = $_POST['keterangan_paket'];
    $katergori = $_POST['kategori'];

    $sql = "INSERT INTO paket_grooming VALUES
    (null, :nama_paket, :jenis_hewan, :harga, :keterangan_grooming)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':nama_paket', $nama_paket, PDO::PARAM_STR);
    $stmt->bindParam(':jenis_hewan', $katergori, PDO::PARAM_STR);
    $stmt->bindParam(':harga', $harga, PDO::PARAM_INT);
    $stmt->bindParam(':keterangan_grooming', $keterangan, PDO::PARAM_STR);

    if ($stmt->execute()) {
        $_SESSION['success'] = "paket berhasil ditambahkan";
    } else {
        echo "ERROR - gagal";
        $_SESSION['failed'] = "Terjadi kesalahan paket gagal dibuat.";
    }

    header("Location: ../pages/admin/grooming_dashboard.php");
    exit();
}

// ini untuk update produk
if (isset($_POST['edit_produk'])) {
    // print_r($_POST);
    // die();
    
    $id_produk = $_POST['id_produk'];
    $nama_produk = $_POST['nama_produk'];
    $kategori = $_POST['kategori'];
    $harga = $_POST['harga'];
    $gambar = $_FILES['gambar_produk']['name'];
    $tgl_produksi = $_POST['tgl_produksi'];
    $tgl_expired = $_POST['tgl_expired'];
    $nama_produk = $_POST['nama_produk'];
    $stock = $_POST['stock'];

    $sql= "SELECT * from produk where id_produk = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id_produk, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if($_FILES['gambar_produk']['name'] === " ") {
        $gambar = $result['gambar_produk'];
    
    }else {
        $path = "../assets/product_item/" . $gambar;
        $tmp_file = $_FILES['gambar_produk']['tmp_name'];
        move_uploaded_file($tmp_file, $path);   
    }

    $sqlUpdate= "UPDATE produk SET nama= :nama,
                                    kategori= :kategori,
                                    stock= :stock,
                                    harga= :harga,
                                    gambar= :gambar,
                                    tgl_dibuat= :tgl_dibuat,
                                    tgl_expired= :tgl_expired where id_produk = :id";
                                    
    $stmtUpdate= $conn->prepare($sqlUpdate);
    $stmtUpdate->bindParam(':id', $id_produk, PDO::PARAM_INT);
    $stmtUpdate->bindParam(':nama', $nama_produk, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':kategori', $kategori, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':stock', $stock, PDO::PARAM_INT);
    $stmtUpdate->bindParam(':harga', $harga, PDO::PARAM_INT);
    $stmtUpdate->bindParam(':gambar', $gambar, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':tgl_dibuat', $tgl_produksi, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':tgl_expired', $tgl_expired, PDO::PARAM_STR);
    
    if ($stmtUpdate->execute()) {
        $_SESSION['success'] = "produk berhasil diedit";
    } else {
        echo "ERROR - gagal";
        $_SESSION['failed'] = "Terjadi kesalahan Produk gagal diedit.";
    }

    header("Location: ../pages/admin/product_dashboard.php");
    exit();


    // EDIT USER
} elseif (isset($_POST['edit_user'])) {
    $id_user = $_POST['id_user'];
    $nama_user = $_POST['full_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $telepon = $_POST['no_hp'];
    $alamat = $_POST['alamat'];

    if (!empty($_POST['password'])) {
        $password = $_POST['password'];
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    } else {
        $hashedPassword = null;
    }

    $sqlUpdate = "UPDATE users SET full_name = :full_name,
                                    username = :username,
                                    email = :email,
                                    no_hp = :no_hp,
                                    alamat = :alamat" . 
                                    ($hashedPassword ? ", password = :password" : "") . 
                                    " WHERE id = :id";
                                    
    $stmtUpdate = $conn->prepare($sqlUpdate);
    $stmtUpdate->bindParam(':id', $id_user, PDO::PARAM_INT);
    $stmtUpdate->bindParam(':full_name', $nama_user, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':username', $username, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':email', $email, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':no_hp', $telepon, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':alamat', $alamat, PDO::PARAM_STR);
    
    // Bind the password only if it's provided
    if ($hashedPassword) {
        $stmtUpdate->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
    }

    if ($stmtUpdate->execute()) {
        $_SESSION['success'] = "User  berhasil diedit";
    } else {
        echo "ERROR - gagal";
        $_SESSION['failed'] = "Terjadi kesalahan User gagal diedit.";
    }

    header("Location: ../pages/admin/user_dashboard.php");
    exit();

} elseif (isset($_POST['edit_paket'])) {
    // print_r($_POST);
    // die();

    $id_paket = $_POST['id_paket'];
    $nama_paket = $_POST['nama_paket'];
    $harga = $_POST['harga'];
    $keterangan = $_POST['keterangan_paket'];
    $katergori = $_POST['kategori'];

    $sqlUpdate = "UPDATE paket_grooming SET nama_paket = :nama_paket,
                                        jenis_hewan = :jenis_hewan,
                                        harga = :harga,
                                        keterangan_grooming = :keterangan_grooming WHERE id_paket =:id";
                                    
    $stmtUpdate= $conn->prepare($sqlUpdate);
    $stmtUpdate->bindParam(':id', $id_paket, PDO::PARAM_INT);
    $stmtUpdate->bindParam(':nama_paket', $nama_paket, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':harga', $harga, PDO::PARAM_INT);
    $stmtUpdate->bindParam(':keterangan_grooming', $keterangan, PDO::PARAM_STR);
    $stmtUpdate->bindParam(':jenis_hewan', $katergori, PDO::PARAM_STR);
    
    if ($stmtUpdate->execute()) {
        $_SESSION['success'] = "paket berhasil diedit";
    } else {
        echo "ERROR - gagal";
        $_SESSION['failed'] = "Terjadi kesalahan paket gagal diedit.";
    }

    header("Location: ../pages/admin/grooming_dashboard.php");
    exit();
}

//ini untuk hapus produk
if (isset($_GET['hapus'])) {
    // print_r($_GET);
    // die();

    $sql="DELETE FROM produk WHERE id_produk = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $_GET['hapus'], PDO::PARAM_INT);
    if ($stmt->execute()) {
        $_SESSION['success'] = "produk berhasil dihapus";
    } else {
        echo "ERROR - gagal";
        $_SESSION['failed'] = "Terjadi kesalahan Produk gagal dihapus.";
    }

    header("Location: ../pages/admin/product_dashboard.php");
    exit();
} elseif  (isset($_GET['hapus_user'])) {
    // print_r($_GET);
    // die();

    $sql="DELETE FROM users WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $_GET['hapus_user'], PDO::PARAM_INT);
    if ($stmt->execute()) {
        $_SESSION['success'] = "user berhasil dihapus";
    } else {
        echo "ERROR - gagal";
        $_SESSION['failed'] = "Terjadi kesalahan User gagal dihapus.";
    }

    header("Location: ../pages/admin/user_dashboard.php");
    exit();
} elseif (isset($_GET['hapus_paket'])) {
    // print_r($_GET);
    // die();

    $sql="DELETE FROM paket_grooming WHERE id_paket = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $_GET['hapus_paket'], PDO::PARAM_INT);
    if ($stmt->execute()) {
        $_SESSION['success'] = "paket berhasil dihapus";
    } else {
        echo "ERROR - gagal";
        $_SESSION['failed'] = "Terjadi kesalahan paket gagal dihapus.";
    }

    header("Location: ../pages/admin/grooming_dashboard.php");
    exit();
}

if (isset($_GET['confirmPesanan'])) {
    // print_r($_GET);
    // die();
    $status = 'dikirim';

    $sql = "UPDATE pesanan SET status = :status WHERE id_pesanan = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':id', $_GET['confirmPesanan'], PDO::PARAM_INT);
    if ($stmt->execute()) {
        // echo "okee";
        // die();
        $_SESSION['success'] = "Pesanan berasil di diterima";
    } else {
        // echo "ERROR - gagal";
        // die();
        $_SESSION['failed'] = "ERROR - konfrimasi gagal";
    }

    header("Location: ../pages/admin/pesanan_produk.php");
    exit();

} elseif (isset($_GET['rejectPesanan'])) {
    // print_r($_GET);
    // die();
    $status = 'ditolak';

    $sql = "UPDATE pesanan SET status = :status WHERE id_pesanan = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':id', $_GET['rejectPesanan'], PDO::PARAM_INT);
    if ($stmt->execute()) {
        $_SESSION['success'] = "Pesanan ditolak";
    } else {
        echo "ERROR - gagal";
        $_SESSION['failed'] = "ERROR - konfrimasi gagal";
    }

    header("Location: ../pages/admin/pesanan_produk.php");
    exit();

} elseif (isset($_GET['confirmBooking'])) {
    // print_r($_GET);
    // die();
    $status = 'aktif';

    $sql = "UPDATE booking SET status = :status WHERE id_booking = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':id', $_GET['confirmBooking'], PDO::PARAM_INT);
    if ($stmt->execute()) {
        // echo "okee";
        // die();
        $_SESSION['success'] = "booking berasil di dikonfirmasi";
    } else {
        // echo "ERROR - gagal";
        // die();
        $_SESSION['failed'] = "ERROR - konfrimasi gagal";
    }

    header("Location: ../pages/admin/booking.php");
    exit();

} elseif (isset($_GET['rejectBooking'])) {
    $status = 'ditolak';

    $sql = "UPDATE booking SET status = :status WHERE id_booking = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':id', $_GET['rejectBooking'], PDO::PARAM_INT);
    if ($stmt->execute()) {
        // echo "okee"; 
        // die();
        $_SESSION['success'] = "booking berasil di ditolak";
    } else {
        // echo "ERROR - gagal";
        // die();
        $_SESSION['failed'] = "ERROR - konfirmasi gagal";
    }

    header("Location: ../pages/admin/booking.php");
    exit();
}



?>
