<?php 
//nama file: login.php
//deskripsi: login user
//dibuat oleh: front-end dan back-end christain marcelino[3312411008] 
//dibuat tgl: 9/12-28/12



include '../config/koneksi.php'; 
session_start();

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Menggunakan prepared statement untuk mencegah SQL injection
    $sql = "SELECT * FROM users WHERE username = :username";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) { // Memeriksa apakah pengguna ditemukan
        if (password_verify($password, $user['password'])) { // Memeriksa password dengan hashing
            $_SESSION['id'] = $user['id']; // set session untuk id
            $_SESSION['role'] = $user['role']; // set session untuk role

            if ($user['role'] === 'admin') {
                header("Location: admin/");
                exit();
            } elseif ($user['role'] === 'customer') {
                header("Location: costumer/homepage.php");
                exit();
            }
        } else {
            $_SESSION['failed'] = "password/username salah!!";
        }
    } else {
        $_SESSION['failed'] = "user tidak ditemukan";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - MiaWoof PETSHOP</title>
    <link rel="icon" href="../../assets/images/miawoof-logo.jpg" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/login.css">
</head>
<body>
    <section>
        <figure>
            <img src="../assets/images/miawoof-logo.jpg" alt="miawoof-logo">
            <figcaption>MiaWoof PETSHOP</figcaption>
        </figure>

        <form action="login.php" method="POST">
            <div class="form-title">
                <span>Masuk</span>
                <span>Masuk menggunakan akun terdaftar</span>
            </div>
            <div class="input-area">
                <div class="input-group">
                    <input type="text" name="username" placeholder="username" required>
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="password" required>
                    <img src="../assets/icons/eye-off.svg" alt="" class="eyeToggle">
                </div>
            </div>
            <br>
           
            <div class="form-button">
                <button type="submit" name="login">Masuk</button>
                <span>belum punya akun?</span>
                <button type="button" onclick="location.href='register.php#daftar'">Daftar</button>
            </div>
        </form>
        <footer>©2024 PBL1 Kel5 - CMS UMKM</footer>
    </section>

    <section id="ads-area">
        <div class="login-ads">
            <span>MIAWOOF Petshop</span><br>
            <i>teman setia untuk sahabat kecil anda</i>
        </div>
        <div class="frame">
            <div class="slides" id="slides">
                <img src="../assets/images/petAds1.jpg" alt="">
                <img src="../assets/images/petAds2.jpg" alt="">
                <img src="../assets/images/petAds3.jpg" alt="">
                <img src="../assets/images/petAds4.jpg" alt="">
            </div>
        </div>
    </section>


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        setInterval(carousel, 3500);
        document.querySelectorAll(".eyeToggle").forEach((eye) => {
        eye.addEventListener("click", function() {
            console.log("klik!!!!");
            togglePasswordVisibility(this);
            });
        });

        <?php
        if (isset($_SESSION['failed'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['failed']); ?>",
                icon: "error",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['failed']); } ?>

        <?php
        if (isset($_SESSION['success'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['success']); ?>",
                icon: "success",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['success']); } ?>

        <?php
        if (isset($_SESSION['warning'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['warning']); ?>",
                icon: "warning",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['warning']); } ?>
    </script>
</body>
</html>
