<?php 
//nama file: register.php
//deskripsi: register
//dibuat oleh: front-end dan back-end christain marcelino[3312411008] 
//dibuat tgl: 9/12-28/12
include '../config/koneksi.php'; 
session_start();

if (isset($_POST['register'])) {
    $fullname = $_POST['fullname'];
    $no_hp = $_POST['no_hp'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmPass = $_POST['confirmPass'];
    $role = $_POST['role'];
    // print_r($_POST);
    // die();

    // Validasi password
    if ($password !== $confirmPass) {
        $_SESSION['warning'] = "password tidak sesuai <br> coba lagi!!";
        header("Location: register.php");
        exit();
        
    } else {
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Cek apakah username sudah ada
        $sqlCheck = "SELECT * FROM users WHERE username = :username";
        $stmtCheck = $conn->prepare($sqlCheck);
        $stmtCheck->bindParam(':username', $username, PDO::PARAM_STR);
        $stmtCheck->execute();

        if ($stmtCheck->rowCount() > 0) {
            $_SESSION['warning'] = "username sudah ada coba username lain";
            header("Location: register.php");
            exit();
        } else {
            // Siapkan query untuk menyimpan data pengguna
            $sqlInsert = "INSERT INTO users(full_name, no_hp, email, username, password, role) VALUES (:fullname, :no_hp, :email, :username, :password, :role)";
            $stmtInsert = $conn->prepare($sqlInsert);
            $stmtInsert->bindParam(':fullname', $fullname, PDO::PARAM_STR);
            $stmtInsert->bindParam(':no_hp', $no_hp, PDO::PARAM_STR);
            $stmtInsert->bindParam(':email', $email, PDO::PARAM_STR);
            $stmtInsert->bindParam(':username', $username, PDO::PARAM_STR);
            $stmtInsert->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
            $stmtInsert->bindParam(':role', $role, PDO::PARAM_STR);

            // Eksekusi query
            if ($stmtInsert->execute()) {
                $_SESSION['success'] = "berhasil buat akun";
            } else {
                $_SESSION['failed'] = "terjadi kesalahan coba lagi";
            }
            
            header("Location: login.php");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - MiaWoof PETSHOP</title>
    <link rel="icon" href="../assets/images/miawoof-logo.jpg" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/register.css">
</head>

<body>
    <main>
        <figure>
            <img src="../assets/images/miawoof-logo.jpg" alt="miawoof-logo">
            <figcaption>MiaWoof PETSHOP</figcaption>
        </figure>

        <form action="register.php" method="POST">
            <section id="daftar">
                <div class="form-title">
                    <span>Daftar</span>
                    <span>Daftar data diri anda</span>
                </div>
                <div class="input-area">
                    <div class="input-group">
                        <input type="text" name="fullname" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="input-group">
                        <input type="text" name="no_hp" placeholder="No. Handphone" required>
                    </div>
                    <div class="input-group">
                        <input type="email" name="email" placeholder="Email" required>
                    </div>
                    <select class="role-selection" name="role" required>
                        <option value="" disabled selected>Pilih Role</option>
                        <option value="customer">Customer</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="form-button">
                    <button type="button" onclick="document.getElementById('buatAkun').scrollIntoView();">Selanjutnya</button>
                    <span>sudah punya akun?</span>
                    <button type="button" onclick="location.href='login.php'">Masuk</button>
                </div>
            </section>
            <section id="buatAkun">
                <div class="form-title">
                    <span>Buat Akun</span>
                    <span>Buat username dan password anda</span>
                </div>
                <div class="input-area">
                    <div class="input-group">
                        <input type="text" name="username" placeholder="Username" required>
                    </div>
                    <div class="input-group">
                        <input type="password" name="password" placeholder="password" required>
                        <img src="../assets/icons/eye-off.svg" alt="" class="eyeToggle">
                    </div>
                    <div class="input-group">
                        <input type="password" name="confirmPass" placeholder="konfirmasi password" required>
                        <img src="../assets/icons/eye-off.svg" alt="" class="eyeToggle">
                    </div>
                </div>
                <div class="form-button">
                    <button type="submit" name="register" id="submit-btn">Buat akun</button>
                    <span>sudah punya akun?</span>
                    <button type="button" onclick="location.href='#daftar'">Kembali</button>
                </div>
            </section>
        </form>
        <footer>©2024 PBL1 Kel5 - CMS UMKM</footer>
    </main>

    <article id="ads-area">
        <div class="login-ads">
            <span>MIAWOOF Petshoop</span><br>
            <i>teman setia untuk sahabat kecil anda</i>
        </div>
        <div class="frame">
            <div class="slides" id="slides">
                <img src="../assets/images/petAds1.jpg" alt="">
                <img src="../assets/images/petAds2.jpg" alt="">
                <img src="../assets/images/petAds3.jpg" alt="">
                <img src="../assets/images/petAds4.jpg" alt="">
            </div>
        </div>
    </article>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        setInterval(carousel, 3500);
        document.querySelectorAll(".eyeToggle").forEach((eye) => {
            eye.addEventListener("click", function() {
                togglePasswordVisibility(this);
            });
        });

        <?php
        if(isset($_SESSION['warning'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['warning']); ?>",
                icon: "warning",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['warning']); } ?>
    </script>
</body>

</html>