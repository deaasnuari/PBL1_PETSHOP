<?php 
//nama file: ringkasan pesanan.php
//deskripsi: menampilkan ringkasan pesanan yang telah dilakukan oleh user
//dibuat oleh: front-end dan back-end dea asnuari[3312411001] 
//dibuat tgl: 9/12-28/12
include "../../config/koneksi.php";
include "../../controller/function.php";
session_start();

if(!isset($_POST['detail_pesanan'])) {
    header("Location: produkdetail.php");
    exit();

} else {
    $jumlah = $_POST['jumlah'];
    $id_produk = $_POST['id_produk'];
    
    $id_pembeli = $_SESSION['id'];
    // $id_pembeli = 9;

    $sql = "SELECT * FROM produk WHERE id_produk = $id_produk";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $produk = $stmt->fetch(PDO::FETCH_ASSOC);

    $total = $produk['harga'] * $jumlah;

    $sql = "SELECT * FROM users WHERE id = $id_pembeli";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $pembeli = $stmt->fetch(PDO::FETCH_ASSOC);

    if (empty($pembeli['alamat'])) {
        $_SESSION['warning'] = "silahkan masukan alamat anada terlebih dahulu";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login - MiaWoof PETSHOP</title>
    <link rel="icon" href="../../assets/images/miawoof-logo.jpg" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Inria+Sans:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Irish+Grover&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/costumer/template.css">
    <link rel="stylesheet" href="../../assets/css/costumer/ringkasanpesanan.css">
</head>

<body>
    <div id="header-container" style="height: 200px;">
        <script>
            fetch('../../layout/costumer/costumer_header.html')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                    const openSidebarElements = document.querySelectorAll(".openSidebar");
                    const closeSidebar = document.getElementById("closeSidebar");
                    Array.from(openSidebarElements).forEach(element => {
                        element.addEventListener("click", sidebarToggle);
                    });
                    closeSidebar.addEventListener("click", sidebarToggle);
                })
                .catch(error => console.error('Error loading header:', error));
        </script>
    </div>

    <main>
        <h2 align="center" class="main-header">Ringkasan Pesanan</h2>
        <section class="costumer-info">
            <span>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="feather feather-map-pin">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                </svg>
                <b><?= $pembeli['full_name'];?></b>
            </span> 
            <span><?= $pembeli['no_hp'];?></span><br>
            <span><?= $pembeli['alamat'];?></span>
        </section>
        <section class="produk-info">
            <div>
                <h3>Detail Produk</h3>
            </div>
            <div class="produk-detail">
                <img src="../../assets/product_item/<?= $produk['gambar']?>" width="150px" alt="">
                <div class="produk-detail-section">
                    <h2 id="displayProductName"><?= $produk['nama']?></h2>
                    <div class="production">
                        <span><b>tanggal produksi</b></span>
                        <span><?= $produk['tgl_dibuat']?></span>
                    </div>
                    <div class="expired">
                        <span><b>kadaluarsa</b></span>
                        <span><?= $produk['tgl_expired']?></span>
                    </div>
                </div>
            </div>
        </section>
        <section class="detail-harga">
            <div>
                <h3>Detail Harga</h3>
            </div>
            <div class="detail-harga-section">
                <div class="harga-section">
                    <span>jumlah barang dipesan</span>
                    <span id="displayJumlah"><?= $jumlah ?></span>
                </div>
                <div class="harga-section">
                    <span>Harga barang</span>
                    <span id="displayHarga"><?= formatCurrency($produk['harga'])?></span>
                </div>
                <div class="harga-section total">
                    <span>total</span>
                    <span id="displayTotal"><?= formatCurrency($total)?></span>
                </div>
            </div>
        </section>

        <form action="../../controller/costumerController.php" method="POST" class="button-section" id="orderForm">
            <input type="hidden" name="id_pembeli" value=<?= $id_pembeli ?>>
            <input type="hidden" name="id_produk" value=<?= $id_produk ?>>
            <input type="hidden" name="jumlah" value=<?= $jumlah ?>>
            <input type="hidden" name="total" value=<?= $total?>>
            <input type="hidden" name="pesanan">
            <button type="submit" id="submitBtn">pesan sekarang</button>
            <button onclick="window.history.back()" id="cancelBtn">Batal</button>
        </form>

    </main>

    <div id="footer-container">
        <script>
            fetch('../../layout/costumer/costumer_footer.html')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('footer-container').innerHTML = data;
                })
                .catch(error => console.error('Error loading header:', error));
        </script>
    </div>

    <!-- ini cdn untuk popUp start -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- ini cdn untuk popUp end -->

    <script src="../../assets/js/script.js"></script>
    <script>
        const formSubmit = document.getElementById("orderForm");
        formSubmit.addEventListener("submit", (event) => {
            event.preventDefault();
            Swal.fire({
                title: "Sudah yakin dengan pesanan anda?",
                showCancelButton: true,
                confirmButtonText: "Ya",
                cancelButtonText: "Batal",
                confirmButtonColor: "#875749"
            }).then((result) => {
                if (result.isConfirmed) {
                    formSubmit.submit();
                }
            });
        })

        <?php
        if (isset($_SESSION['warning'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['warning']); ?>",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Ya",
                cancelButtonText: "Nanti",
                confirmButtonColor: "#875749"
            }).then((result) => {
                if (result.isConfirmed) {
                    location.href='profil.php';
                } else {
                    window.history.back();
                }
            });
        <?php unset($_SESSION['warning']); } ?>
    </script>
</body>

</html>