<?php
//nama file: produk detail.php
//deskripsi: menampilkan detail produk
//dibuat oleh: front-end dea asnuari[3312411001] back-end hamdan azmi[3312411004]
//dibuat tgl: 9/12-28/12

// Menghubungkan ke file konfigurasi database dan fungsi tambahan
include "../../config/koneksi.php";
include "../../controller/function.php";

// Mengecek apakah parameter 'produk' ada pada URL
if (!isset($_GET['produk'])) {
    header("Location: homepage.php");

} else {
    $id = $_GET['produk'];
    
    // Query untuk mengambil data produk berdasarkan ID
    $sql = "SELECT * FROM produk WHERE id_produk = $id";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $produk = $stmt->fetch(PDO::FETCH_ASSOC);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login - MiaWoof PETSHOP</title>
    <link rel="icon" href="../../assets/images/miawoof-logo.jpg" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Inria+Sans:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Irish+Grover&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/costumer/template.css">
    <link rel="stylesheet" href="../../assets/css/costumer/produkdetail.css">
</head>

<body>
    <div id="header-container" style="height: 200px;">
        <!-- Mengambil header dari file eksternal menggunakan fetch -->
        <script>
        fetch('../../layout/costumer/costumer_header.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
                const openSidebarElements = document.querySelectorAll(".openSidebar");
                const closeSidebar = document.getElementById("closeSidebar");
                Array.from(openSidebarElements).forEach(element => {
                    element.addEventListener("click", sidebarToggle);
                });
                closeSidebar.addEventListener("click", sidebarToggle);
            })
            .catch(error => console.error('Error loading header:', error));
        </script>
    </div>
    <main>
        <section class="produk-detail">
            <div>
                <!-- Menampilkan gambar produk -->
                <img src="../../assets/product_item/<?=$produk['gambar']?>" width="170" alt="" class="product-img">
            </div>
            <form method="POST" action="ringkasanpesanan.php">
                 <!-- Menampilkan detail produk -->
                <h2><?= $produk['nama']; ?></h2>
                <h3><?= formatCurrency($produk['harga']); ?></h3>
               <!-- Pilihan jumlah pembelian -->
                <div class="qtty-btn">
                    <img src="../../assets/icons/minus.svg" id="decreament">
                    <span id="qtyDisplay">1</span>
                    <img src="../../assets/icons/plus.svg" id="increament">
                </div>
                <div>Stock : <?= $produk['stock'] ?></div>

                 <!-- Input hidden untuk mengirim data -->
                <input type="hidden" name="jumlah" value= 1 id="qtyValue">
                <input type="hidden" name="id_produk" value=<?= $produk['id_produk']?>>
                <button type="submit" name="detail_pesanan">Checkout</button>
            </form>
        </section>
        <section class="produk-info">
            <!-- Menampilkan informasi produk -->
            <div class=" produk-info-head"><span>detail</span><span>info penting</span></div>
            <div class="detail-info">
                <div class="detail">
                    <ul>
                        <li>Nama: <?= $produk['nama']; ?></li>
                        <li>Harga: <?= formatCurrency($produk['harga']); ?></li>
                        <li>jenis hewan: <?= $produk['kategori']; ?></li>
                        <li>expired: <?= $produk['tgl_expired']; ?></li>
                    </ul>
                </div>
                <div class="info">
                    <!-- Informasi penting terkait kebijakan toko -->
                    <p>
                        <b>Kebijakan Pengembalian Produk</b><br>
                        <span> Barang yang sudah dibeli tidak dapat DITUKAR, DIKEMBALIKAN atau REFUND dengan alasan
                            Apapun!!!</span>
                        <br><br>
                        <b>CATATAN TOKO</b><br>
                        <span>Pengiriman pesanan selalu kami usahakan untuk secepat mungkin di hari yg sama atau paling
                            lama 2 hari (2x24 jam). </span>
                    </p>
                </div>
            </div>
        </section>
    </main>

    <div id="footer-container">
        <script>
        fetch('../../layout/costumer/costumer_footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            })
            .catch(error => console.error('Error loading header:', error));
        </script>
    </div>

    <script src="../../assets/js/script.js"></script>
    <script>
    let increase = document.getElementById('increament');
    let decrease = document.getElementById('decreament');
    let qtyDisplay = document.getElementById('qtyDisplay');
    let qty = document.getElementById('qtyValue');

    let defaultQty = 1

     // Event listener untuk tombol tambah
    increase.addEventListener("click", () => {
        defaultQty = Math.min(defaultQty + 1, 30);
        qtyDisplay.innerText = defaultQty
        qty.value = defaultQty
        // console.log(qty.value);

    })

    // Event listener untuk tombol kurang
    decrease.addEventListener("click", () => {
        defaultQty = Math.max(defaultQty - 1, 1);
        qtyDisplay.innerText = defaultQty
        qty.value = defaultQty
        // console.log(qty.value);
    })
    </script>
</body>

</html>