<?php 
//nama file: status pembayaran.php
//deskripsi: menampilkan status pembayaran
//dibuat oleh: front-end dan back-end setya prmudiya hakim[3312411030] 
//dibuat tgl: 9/12-28/12
include "../../config/koneksi.php";
include "../../controller/function.php";
session_start();

$sql = "SELECT * FROM pesanan ps
        JOIN produk p ON ps.id_produk = p.id_produk
        JOIN users u ON ps.id_pembeli = u.id
         ORDER BY ps.status = 'menunggu pembayaran  ' DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login - MiaWoof PETSHOP</title>
    <link rel="icon" href="../../assets/images/miawoof-logo.jpg" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Inria+Sans:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Irish+Grover&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/costumer/template.css">
    <link rel="stylesheet" href="../../assets/css/costumer/historypembayaran.css">
</head>

<body>
    <!--header-->
    <div id="header-container" style="height: 200px;">
        <script>
            fetch('../../layout/costumer/costumer_header.html')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                    const openSidebarElements = document.querySelectorAll(".openSidebar");
                    const closeSidebar = document.getElementById("closeSidebar");
                    Array.from(openSidebarElements).forEach(element => {
                        element.addEventListener("click", sidebarToggle);
                    });
                    closeSidebar.addEventListener("click", sidebarToggle);
                })
                .catch(error => console.error('Error loading header:', error));
        </script>
    </div>

    <main>
        <div class="history-head">
            <h2>History Pembayaran</h2>
        </div>
        <div class="history-list">
            <?php foreach ($result as $pesanan): ?>
            <div class="list">
                <div class="details">
                    <div class="list-detail">
                        <div>Produk</div>
                        <div><b><?= $pesanan['nama'] ?></b></div>
                    </div>
                    <div class="list-detail">
                        <div>Tanggal Pembelian</div>
                        <div><b><?= $pesanan['tgl_pesanan'] ?></b></div>
                    </div>
                    <div class="list-detail">
                        <div>Total Pembayaran</div>
                        <div><b><?= formatCurrency($pesanan['total']) ?></b></div>
                    </div>
                </div>
                <div class="detail-status">
                    <a class="openPopUp">Lihat Detail</a>
                    <a class="status"><?= $pesanan['status'] ?></a>
                </div>
            </div>
            <div class="popUp" style="display: none;">
                <div class="detail-pesanan-modal">
                    <div class="modal-head">
                        <span><b>Detail Pesanan
                                <?= $pesanan['id_pesanan'] ?>
                            </b></span>
                    </div>
                    <div>
                        <span><b>Total Belanja</b></span>
                        <div class="detail-harga">
                            <span>Total Harga <?= $pesanan['jumlah'] . 'x' ?></span>
                            <span><b><?= formatCurrency($pesanan['total'])?></b></span>
                        </div>
                    </div>
                    <div class="detail-alamat">
                        <span><b>Alamat</b></span><br>
                        <span><?= $pesanan['alamat'] ?></span>
                    </div>
                    <div class="rekening-miawoof">
                        <span><b>Rekening MiaWoof</b></span><br>
                        <span>00887766776528</span>
                    </div>
                    <div class="action-button">
                        <button class="closePopUp">Oke !</button>
                        <button class="konfirmasiHapus" data-id="<?= $pesanan['id_pesanan']?>">Batalkan Pesanan</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>




    <div id="footer-container">
        <script>
            fetch('../../layout/costumer/costumer_footer.html')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('footer-container').innerHTML = data;
                })
                .catch(error => console.error('Error loading header:', error));
        </script>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../../assets/js/script.js"></script>
    <script>
        //function untuk membuka modal detail pesanan - start
        function PopUp(index) {
            const popUps = document.querySelectorAll('.popUp');
            const popUp = popUps[index];
            if (popUp.style.display === 'none' || popUp.style.display === '') {
                popUp.style.display = 'flex';

                // memberi modal dialog untuk konfirmasi hapus ke pembeli - start
                if (popUp.style.display = 'flex') {
                    const openPopUp = document.querySelectorAll('.konfirmasiHapus')
                    openPopUp.forEach(confirmBtn => {
                        confirmBtn.addEventListener('click', () => {
                            popUp.style.display = 'none';
                            const id_pesanan = confirmBtn.getAttribute('data-id')
                            Swal.fire({
                                title: "Yakin ingin membatalkan pesanan ini?",
                                text: "kamu tidak akan dapat mengembalikan ini!",
                                icon: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#2E5B7A",
                                cancelButtonColor: "#DD332A",
                                confirmButtonText: "Ya, Hapus!"
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    location.href = `../../controller/costumerController.php?hapus_pesanan=${id_pesanan}`
                                }
                            });
                        })
                    });
                }
                // memberi modal dialog untuk konfirmasi hapus ke pembeli - end
            } else {
                popUp.style.display = 'none';
            }
        }
        //function untuk membuka modal detail pesanan - end

        // memberikan event listener ke button buka/tutup modal - start
        const openPopUp = document.querySelectorAll('.openPopUp');
        openPopUp.forEach((element, index) => {
            element.addEventListener('click', () => PopUp(index));
        });

        const closePopUps = document.querySelectorAll('.closePopUp');
        closePopUps.forEach((closeButton, index) => {
            closeButton.addEventListener('click', () => PopUp(index));
        });
        // memberikan event listener ke button buka/tutup modal - end


        // funtion untuk menetukan warna status pesanan - start
        function statusColor(statusDisplay) {
            const status = statusDisplay.innerText

            if (status === 'dikirim') {
                statusDisplay.className = 'confirm'
            } else if (status === 'ditolak') {
                statusDisplay.className = 'danger'
            } else {
                statusDisplay.className = 'pending'
            }
        }
        const statusElement = document.querySelectorAll('.status');

        statusElement.forEach(statusDisplay => {
            statusColor(statusDisplay);
        });
        // menerapkan function di setiap tag dengan class 'status' - end


        // pop up untuk pesanan berhasil dibuat - start
        <?php
        if(isset($_SESSION['pesanan_berhasil'])) { ?>
            Swal.fire({
                title:  "<?= $_SESSION['pesanan_berhasil']; ?>",
                icon: "success",
                confirmButtonColor: "#875749"
            });
        <?php 
        unset($_SESSION['pesanan_berhasil']); 
        // pop up untuk pesanan berhasil dibuat - end


        // pop up untuk pesanan berhasil dihapus - start
        } elseif (isset($_SESSION['hapus_berhasil'])) { ?>
                Swal.fire({
                    title:  "<?= $_SESSION['hapus_berhasil']; ?>",
                    icon: "success",
                    confirmButtonColor: "#875749"
                });
        <?php unset($_SESSION['hapus_berhasil']); 
        // pop up untuk pesanan berhasil dihapus - end


        // pop up untuk pesanan gagal dihapus - start
        } elseif (isset($_SESSION['hapus_gagal'])) { ?>
            Swal.fire({
                title:  "<?= $_SESSION['hapus_gagal']; ?>",
                icon: "error",
                confirmButtonColor: "#875749"
            });
        <?php unset($_SESSION['hapus_gagal']);
        }
        ?>
         // pop up untuk pesanan gagal dihapus - end

    </script>
</body>

</html>