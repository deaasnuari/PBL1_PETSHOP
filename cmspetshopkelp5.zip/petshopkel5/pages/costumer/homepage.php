<?php
//nama file: hommepage.php
//deskripsi: halaman utama aplikasi
//dibuat oleh: front-end dan back-end christian marcelino[3312411008] 
include "../../config/koneksi.php";
include "../../controller/function.php";
session_start();

if(!isset($_SESSION['id'])) { // jika tidak ada session['id'] makan akan kemabli ke halaman login
    header("Location: ../login.php");
    exit();

} elseif(isset($_GET['kucing'])) {
    $sql = "SELECT * FROM produk WHERE kategori = 'kucing'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

} elseif(isset($_GET['anjing'])) {
    $sql = "SELECT * FROM produk WHERE kategori = 'anjing'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

} elseif(isset($_POST['cari'])) {
    $keyword = $_POST['cari'];
    $query = "SELECT * FROM produk WHERE nama LIKE :keyword";
    $stmt = $conn->prepare($query);
    $searchTerm = '%' . $keyword . '%';
    $stmt->bindParam(':keyword', $searchTerm, PDO::PARAM_STR);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

} else { // menampilkan default semua produk
    $sql = "SELECT * FROM produk";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login - MiaWoof PETSHOP</title>
    <link rel="icon" href="../../assets/images/miawoof-logo.jpg" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Inria+Sans:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Irish+Grover&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/costumer/template.css">
    <link rel="stylesheet" href="../../assets/css/costumer/homepage.css">
</head>

<body>
    <div id="header-container" style="height: 200px;">
        <script>
        fetch('../../layout/costumer/costumer_header.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header-container').innerHTML = data;
                const openSidebarElements = document.querySelectorAll(".openSidebar");
                const closeSidebar = document.getElementById("closeSidebar");
                Array.from(openSidebarElements).forEach(element => {
                    element.addEventListener("click", sidebarToggle);
                });
                closeSidebar.addEventListener("click", sidebarToggle);
            })
            .catch(error => console.error('Error loading header:', error));
        </script>
    </div>


    <main>
        <div class="corousel">
            <div class="slides" id="slides">
                <img src="../../assets/images/Frame 89.png">
                <img src="../../assets/images/Frame 89.png">
                <img src="../../assets/images/Frame 89.png">
                <img src="../../assets/images/Frame 89.png">
            </div>
        </div>
        <div class="category-nav">
            <a href="homepage.php?kucing">
                <img src="../../assets/images/cat_1998592.png" width="60" alt="">
                <span>Kucing</span>
            </a>
            <a href="homepage.php?anjing">
                <img src="../../assets/images/dog_1998627.png" width="60" alt="">
                <span>Anjing</span>
            </a>
        </div>

        <div class="products-display">
            <div class="display-head">Product</div>
            <div class="products" id="elementContainer">
                <?php foreach($result as $produk):?>
                <a href="produkdetail.php?produk=<?= $produk['id_produk'] ?>" class="element">
                    <div class="card">
                        <img class="product-img" src="../../assets/product_item/<?=$produk['gambar']?>" class="product-img">
                        <span><?= $produk['nama'];?></span>
                        <div class="price-tag"><b><?= formatCurrency($produk['harga']) ?></b></div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </main>

    <div id="footer-container">
        <script>
        fetch('../../layout/costumer/costumer_footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            })
            .catch(error => console.error('Error loading header:', error));
        </script>
    </div>

    <script src="../../assets/js/script.js"></script>
    <script>
    setInterval(carousel, 3500)
    </script>
</body>

</html>