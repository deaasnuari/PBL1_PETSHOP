<?php 
//nama file: booking.php
//deskripsi: menampilkan data booking   
//dibuat oleh: [fatra syahreza[3312411031] dan back-end christian marcelino[3312411008]]
//tgl dibuat: 9/12-28/12
include "../../config/koneksi.php";
session_start();


if(!isset($_SESSION['id'])) {
    header("Location: homepage.php");
    exit();
} else {
    $id = $_SESSION['id'];
    // $id = 16;
    
    $sql = "SELECT * FROM users WHERE id = $id";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $costumer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (empty($costumer['alamat'])) {
        $_SESSION['warning'] = "silahkan masukan alamat anada terlebih dahulu";
    }
    // print_r($costumer);
    // die();
}





?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login - MiaWoof PETSHOP</title>
    <link rel="icon" href="../../assets/images/miawoof-logo.jpg" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Inria+Sans:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Irish+Grover&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/costumer/template.css">
    <link rel="stylesheet" href="../../assets/css/costumer/booking.css">
</head>

<body>
    <div id="header-container" style="height: 200px;">
        <script>
            fetch('../../layout/costumer/costumer_header.html')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                    const openSidebarElements = document.querySelectorAll(".openSidebar");
                    const closeSidebar = document.getElementById("closeSidebar");
                    Array.from(openSidebarElements).forEach(element => {
                        element.addEventListener("click", sidebarToggle);
                    });
                    closeSidebar.addEventListener("click", sidebarToggle);
                })
                .catch(error => console.error('Error loading header:', error));
        </script>
    </div>

    <main>
        <form method="POST" action="../../controller/costumerController.php" id="bookingForm">
            <input type="hidden" name="booking">
            <section class="costumer-section">
                <h3>Booking</h3>
                <div class="input-group">
                    <label for="nama">Nama</label>
                    <input type="text" id="nama" name="nama" value="<?= $costumer['full_name'] ?>" readonly>
                </div>
                <div class="input-group">
                    <label for="no_hp">No. Handphone</label>
                    <input type="text" id="no_hp" name="no_hp" value="<?= $costumer['no_hp'] ?>" readonly>
                </div>
                <div class="input-group">
                    <label for="alamat">Alamat</label>
                    <input type="text" id="alamat" name="alamat" value="<?= $costumer['alamat'] ?>" readonly>
                </div>
                <input type="hidden" name="id_costumer" value="<?= $costumer['id'] ?>">
            </section>
            <section class="section">
                <h3>Tanggal</h3>
                <div class="input-group">
                    <input type="radio" id="tgl01" name="tgl" value="01" class="radio">
                    <label for="tgl01">01</label>
                    <input type="radio" id="tgl02" name="tgl" value="02" class="radio">
                    <label for="tgl02">02</label>
                    <input type="radio" id="tgl03" name="tgl" value="03" class="radio">
                    <label for="tgl03">03</label>
                    <input type="radio" id="tgl04" name="tgl" value="04" class="radio">
                    <label for="tgl04">04</label>
                    <input type="radio" id="tgl05" name="tgl" value="05" class="radio">
                    <label for="tgl05">05</label>
                    <input type="radio" id="tgl06" name="tgl" value="06" class="radio">
                    <label for="tgl06">06</label>
                    <input type="radio" id="tgl07" name="tgl" value="07" class="radio">
                    <label for="tgl07">07</label>
                    <input type="radio" id="tgl08" name="tgl" value="08" class="radio">
                    <label for="tgl08">08</label>
                    <input type="radio" id="tgl09" name="tgl" value="09" class="radio">
                    <label for="tgl09">09</label>
                    <input type="radio" id="tgl10" name="tgl" value="10" class="radio">
                    <label for="tgl10">10</label>
                    <input type="radio" id="tgl11" name="tgl" value="11" class="radio">
                    <label for="tgl11">11</label>
                    <input type="radio" id="tgl12" name="tgl" value="12" class="radio">
                    <label for="tgl12">12</label>
                    <input type="radio" id="tgl13" name="tgl" value="13" class="radio">
                    <label for="tgl13">13</label>
                    <input type="radio" id="tgl14" name="tgl" value="14" class="radio">
                    <label for="tgl14">14</label>
                    <input type="radio" id="tgl15" name="tgl" value="15" class="radio">
                    <label for="tgl15">15</label>
                    <input type="radio" id="tgl16" name="tgl" value="16" class="radio">
                    <label for="tgl16">16</label>
                    <input type="radio" id="tgl17" name="tgl" value="17" class="radio">
                    <label for="tgl17">17</label>
                    <input type="radio" id="tgl18" name="tgl" value="18" class="radio">
                    <label for="tgl18">18</label>
                    <input type="radio" id="tgl19" name="tgl" value="19" class="radio">
                    <label for="tgl19">19</label>
                    <input type="radio" id="tgl20" name="tgl" value="20" class="radio">
                    <label for="tgl20">20</label>
                    <input type="radio" id="tgl21" name="tgl" value="21" class="radio">
                    <label for="tgl21">21</label>
                    <input type="radio" id="tgl22" name="tgl" value="22" class="radio">
                    <label for="tgl22">22</label>
                    <input type="radio" id="tgl23" name="tgl" value="23" class="radio">
                    <label for="tgl23">23</label>
                    <input type="radio" id="tgl24" name="tgl" value="24" class="radio">
                    <label for="tgl24">24</label>
                    <input type="radio" id="tgl25" name="tgl" value="25" class="radio">
                    <label for="tgl25">25</label>
                    <input type="radio" id="tgl26" name="tgl" value="26" class="radio">
                    <label for="tgl26">26</label>
                    <input type="radio" id="tgl27" name="tgl" value="27" class="radio">
                    <label for="tgl27">27</label>
                    <input type="radio" id="tgl28" name="tgl" value="28" class="radio">
                    <label for="tgl28">28</label>
                    <input type="radio" id="tgl29" name="tgl" value="29" class="radio">
                    <label for="tgl29">29</label>
                    <input type="radio" id="tgl30" name="tgl" value="30" class="radio">
                    <label for="tgl30">30</label>
                    <input type="radio" id="tgl31" name="tgl" value="31" class="radio">
                    <label for="tgl31">31</label>
                </div>
            </section>
            <section class="section">
                <h3>Bulan</h3>
                <div class="input-group">
                    <input type="radio" id="01" name="bulan" value="01" class="radio">
                    <label for="01">jan</label>
                    <input type="radio" id="02" name="bulan" value="02" class="radio">
                    <label for="02">feb</label>
                    <input type="radio" id="03" name="bulan" value="03" class="radio">
                    <label for="03">mar</label>
                    <input type="radio" id="04" name="bulan" value="04" class="radio">
                    <label for="04">apr</label>
                    <input type="radio" id="05" name="bulan" value="05" class="radio">
                    <label for="05">mei</label>
                    <input type="radio" id="06" name="bulan" value="06" class="radio">
                    <label for="06">jun</label>
                    <input type="radio" id="07" name="bulan" value="07" class="radio">
                    <label for="07">jul</label>
                    <input type="radio" id="08" name="bulan" value="08" class="radio">
                    <label for="08">agu</label>
                    <input type="radio" id="09" name="bulan" value="09" class="radio">
                    <label for="09">sep</label>
                    <input type="radio" id="10" name="bulan" value="10" class="radio">
                    <label for="10">okt</label>
                    <input type="radio" id="11" name="bulan" value="11" class="radio">
                    <label for="11">nov</label>
                    <input type="radio" id="12" name="bulan" value="12" class="radio">
                    <label for="12">des</label>
                </div>
            </section>
            <section class="section">
                <h3>Waktu</h3>
                <div class="input-group">
                    <input type="radio" id="09.00" name="waktu" value="09.00" class="radio">
                    <label for="09.00">09:00</label>
                    <input type="radio" id="10.00" name="waktu" value="10.00" class="radio">
                    <label for="10.00">10:00</label>
                    <input type="radio" id="11.00" name="waktu" value="11.00" class="radio">
                    <label for="11.00">11:00</label>
                    <input type="radio" id="12.00" name="waktu" value="12.00" class="radio">
                    <label for="12.00">12:00</label>
                    <input type="radio" id="13.00" name="waktu" value="13.00" class="radio">
                    <label for="13.00">13:00</label>
                    <input type="radio" id="14.00" name="waktu" value="14.00" class="radio">
                    <label for="14.00">14:00</label>
                    <input type="radio" id="15.00" name="waktu" value="15.00" class="radio">
                    <label for="15.00">15:00</label>
                    <input type="radio" id="16.00" name="waktu" value="16.00" class="radio">
                    <label for="16.00">16:00</label>
                    <input type="radio" id="17.00" name="waktu" value="17.00" class="radio">
                    <label for="17.00">17:00</label>
                    <input type="radio" id="18.00" name="waktu" value="18.00" class="radio">
                    <label for="18.00">18:00</label>
                </div>
            </section>
            <section class="section">
                <h3>Kategori Hewan</h3>
                <div class="input-group">
                    <input type="radio" id="kucing" name="hewan" value="kucing" class="radio">
                    <label for="kucing">Kucing</label>
                    <input type="radio" id="anjing" name="hewan" value="anjing" class="radio">
                    <label for="anjing">Anjing</label>
                </div>
            </section>
            <section class="section">
                <h3>Level Paket</h3>
                <div class="input-group">
                    <input type="radio" id="reguler" name="paket_kategori" value="reguler" class="radio">
                    <label for="reguler">Reguler</label>
                    <input type="radio" id="premium" name="paket_kategori" value="premium" class="radio">
                    <label for="premium">Premium</label>
                </div>
            </section>
            <section class="section">
                <button type="submit" class="action-btn">Booking Sekarang</button>
                <a href="groomingdetail.html" class="action-btn">Batal</a>
            </section>
        </form>
    </main>

    <div id="footer-container">
        <script>
            fetch('../../layout/costumer/costumer_footer.html')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('footer-container').innerHTML = data;
                })
                .catch(error => console.error('Error loading footer:', error));
        </script>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../../assets/js/script.js"></script>
    <script>
        document.querySelectorAll('input[name="hewan"]').forEach(radio => {
            radio.addEventListener('change', function () {
                const selectedOptgroup = document.querySelector(`#jenis-hewan optgroup[label="${this.value}"]`);
                document.querySelectorAll('#jenis-hewan optgroup').forEach(optgroup => {
                    optgroup.style.display = 'none';
                });
                if (selectedOptgroup) selectedOptgroup.style.display = 'block';
            });
        });

        const formSubmit = document.getElementById("bookingForm");
        formSubmit.addEventListener('submit', function (event) {
            const tglSelected = document.querySelector('input[name="tgl"]:checked');
            const bulanSelected = document.querySelector('input[name="bulan"]:checked');
            const waktuSelected = document.querySelector('input[name="waktu"]:checked');
            const hewanSelected = document.querySelector('input[name="hewan"]:checked');
            const paketSelected = document.querySelector('input[name="paket_kategori"]:checked');

            if (!tglSelected || !bulanSelected || !waktuSelected || !hewanSelected || !paketSelected) {
                event.preventDefault();
                Swal.fire({
                    text: "pastikan semua kolom input sudah terpilih",
                    icon: "warning",
                    confirmButtonColor: "#875749"
                });
            } else {
                event.preventDefault();
                Swal.fire({
                title: "Sudah yakin dengan pesanan anda?",
                showCancelButton: true,
                confirmButtonText: "Ya",
                cancelButtonText: "Batal",
                confirmButtonColor: "#875749"
                }).then((result) => {
                    if (result.isConfirmed) {
                        formSubmit.submit();
                    }
                });
            }
        });

        <?php
        if (isset($_SESSION['warning'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['warning']); ?>",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Ya",
                cancelButtonText: "Nanti",
                confirmButtonColor: "#875749"
            }).then((result) => {
                if (result.isConfirmed) {
                    location.href='profil.php';
                } else {
                    window.history.back();
                }
            });
        <?php unset($_SESSION['warning']); } ?>
    </script>
</body>

</html>