<?php 
//nama file: bookinglist.php
//deskripsi: menampilkan list booking yang telah dilakukan oleh user
//dibuat oleh: hamdan azmi[3312411004] dan back-end fatra syahreza[3312411031]
//tgl dibuat: 9/12-28/12

session_start();
include "../../config/koneksi.php";
include "../../controller/function.php";

$sql = "SELECT * FROM booking bo
        JOIN paket_grooming pg ON bo.id_paket = pg.id_paket
        JOIN users u ON bo.id_costumer = u.id
        ORDER BY bo.status = 'menunggu konfirmasi' DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login - MiaWoof PETSHOP</title>
    <link rel="icon" href="../../assets/images/miawoof-logo.jpg" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Inria+Sans:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Irish+Grover&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/costumer/template.css">
    <link rel="stylesheet" href="../../assets/css/costumer/bookinglist.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/brands.min.css" integrity="sha512-7rXIvd/xj1FnI2zKQjjXzDFxC4twqBByp8yxOgEQJs4C/aNzNyoQsOO7VxH0RgYNhbAYLJLwzqslaP50KTTHIQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <div id="header-container" style="height: 200px;">
        <script>
            fetch('../../layout/costumer/costumer_header.html')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('header-container').innerHTML = data;
                    const openSidebarElements = document.querySelectorAll(".openSidebar");
                    const closeSidebar = document.getElementById("closeSidebar");
                    Array.from(openSidebarElements).forEach(element => {
                        element.addEventListener("click", sidebarToggle);
                    });
                    closeSidebar.addEventListener("click", sidebarToggle);
                })
                .catch(error => console.error('Error loading header:', error));
        </script>
    </div>

    <main>
        <div class="history-head">
            <h2>Booking List</h2>
        </div>
        <div class="history-list">
            <?php foreach($result as $booking): ?>
            <div class="list">
                <div class="no-booking">
                    <span><b><?= "000".$booking['id_booking'] ?></b></span>
                </div>
                <div class="details">
                    <div class="list-detail">
                        <div>Paket</div>
                        <div><b><?= $booking['nama_paket']. " Booking" ?></b></div>
                        <div><b><?= $booking['jenis_hewan']?></b></div>
                    </div>
                    <div class="list-detail">
                        <div>Jadwal Booking</div>
                        <div><b><?= $booking['tgl']. " / " .$booking['bulan']. " / 2024"?></b></div>
                        <div><b><?= $booking['waktu'] ?> WIB</b></div>
                    </div>
                    <div class="list-detail">
                        <div>Total Pembayaran</div>
                        <div><b><?= formatCurrency($booking['harga']) ?></b></div>
                    </div>
                </div>
                <div class="detail-status">
                    <a class="openPopUp" data-id="<?=$booking['id_booking'] ?>">Batalkan booking</a>
                    <a class="status"><?= $booking['status'] ?></a>
                </div>
            </div>
            <?php endforeach;?>
        </div>
    </main>


    <div id="footer-container">
        <script>
            fetch('../../layout/costumer/costumer_footer.html')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('footer-container').innerHTML = data;
                })
                .catch(error => console.error('Error loading header:', error));
        </script>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../../assets/js/script.js"></script>
    <script>
        const openPopUp = document.querySelectorAll('.openPopUp')
        openPopUp.forEach(openPopUp => {
            openPopUp.addEventListener('click', (event) => {
                event.preventDefault()
                const bookingId = openPopUp.getAttribute('data-id')
                Swal.fire({
                    title: "Yakin ingin membatalkan paket booking?",
                    text: "kamu tidak akan dapat mengembalikan ini!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#2E5B7A",
                    cancelButtonColor: "#DD332A",
                    confirmButtonText: "Ya, Hapus!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        location.href = `../../controller/costumerController.php?hapusBooking=${bookingId}`
                    }
                });
            })
        });

        <?php if (isset($_SESSION['hapus_berhasil'])) { ?>
            const text = "<?php echo addslashes($_SESSION['hapus_berhasil']); ?>";
            Swal.fire({
                title: text,
                icon: "success",
                confirmButtonColor: "#875749"
            });
        <?php unset($_SESSION['hapus_berhasil']);   
         } ?>

        // pop up untuk booking berhasil dibuat - start
        <?php
        if(isset($_SESSION['booking_berhasil'])) { ?>
            Swal.fire({
                title:  "<?= $_SESSION['booking_berhasil']; ?>",
                icon: "success",
                confirmButtonColor: "#875749"
            });
        <?php unset($_SESSION['booking_berhasil']);
        } ?>
        // pop up untuk booking berhasil dibuat - end
     
        

        function statusColor(statusDisplay) {
            const status = statusDisplay.innerText

            if (status === 'aktif') {
                statusDisplay.className = 'confirm'
            } else if (status === 'ditolak') {
                statusDisplay.className = 'danger'
            } else {
                statusDisplay.className = 'pending'
            }
        }
        const statusElement = document.querySelectorAll('.status');

        statusElement.forEach(statusDisplay => {
            statusColor(statusDisplay);
        });

    </script>
</body>

</html>