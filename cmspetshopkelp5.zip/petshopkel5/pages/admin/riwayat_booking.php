<?php 
//nama file: [riwayat booking.php]
//deskripsi: menampilkan riwayat booking
//dibuat oleh: [front-end dan back-end christian marcelinho[3312411008]]
//tgl dibuat: 9/12-28/12
include "../../config/koneksi.php";
include "../../controller/function.php";
session_start();

$sql = "SELECT * FROM booking bo
        JOIN paket_grooming pg ON pg.id_paket = bo.id_paket
        JOIN users u ON bo.id_costumer = u.id  WHERE status = 'aktif' OR status = 'ditolak'";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Produk</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap/bootstrap.min.css">
    <!-- costume styling -->
    <style>
        #sidebar.toggled {
            margin-left: -20vw;
        }

        #main-content.toggled {
            margin-left: 0;
        }

        #sidebar,
        #main-content {
            transition: all .3s ease;
        }

        a {
            text-decoration: none;
            color: black;
        }

        .link {
            border-bottom: 2px solid transparent;
            padding: 1rem 0 1rem 1rem;
            transition: .2s ease;
            border-bottom-left-radius: 12px;
        }

        .link:hover {
            padding-left: 1.5rem;
        }

        .link:last-child {
            border: none;
        }

        .active {
            border-bottom: 2px solid #2E5B7A;
            padding-left: 1.5rem;
            font-weight: bold;
            color: #2E5B7A;
        }

        thead th {
            text-align: center;
            vertical-align: middle;
            text-transform: capitalize;
        }

        tbody>tr>td {
            text-align: center;
            vertical-align: middle;
            height: 3.5rem;
        }

        .action>a {
            /* color: white; */
            padding: 5px 1rem;
            font-size: .8rem;
            border-radius: 5px;
            text-transform: capitalize;
        }
    </style>
    <!-- costume styling end -->
</head>

<body style="background-color: #eeeeee;">
    <!-- header -->
    <div class="container-fluid position-sticky top-0" style="height: 14vh; z-index: 2;">
        <div class="row header h-100" style="background-color: #2E5B7A;">
            <div class="d-flex align-items-center gap-2 text-light">
                <img src="../../assets/images/miawoof-logo.jpg" style="width: 4rem" ; class="rounded-circle py-2">
                <span class="fw-bold fs-3">MiaWoof Petshop</span>
            </div>
        </div>
    </div>
    <!-- header end -->
    <div class="container-fluid p-0">
        <div class="d-flex p-0">
            <!-- sidebar -->
            <nav id="sidebar" class="sidebar border d-flex flex-column bg-light position-sticky"
                style="width: 20vw; height: calc(100vh - 14vh); top: 14vh; z-index: 2;">
                <div class="text-center m-3 mt-5">
                    <img src="../..//assets/icons/user.svg" alt="MiaWoof Petshop Logo" style="width: 80px;"
                        class="border border-dark rounded-circle">
                    <p class="fs-5 fw-bold m-0">Admin</p>
                </div>
                <a href="index.html" class="link">Dashboard</a>
                <a href="product_dashboard.php" class="link">Produk</a>
                <a href="pesanan.html" class="link active">Pesanan</a>
                <a href="grooming_dashboard.php" class="link">Grooming</a>
                <a href="user_dashboard.php" class="link">Data User</a>
                <a href="../logout.php" class="link mt-auto d-flex gap-2">
                    <img src="../../assets/icons/log-out.svg" width="18px" alt="">Logout
                </a>
            </nav>
            <!-- sidebar end -->

            <!-- main content -->
            <div id="main-content" class="container-fluid p-0">
                <nav class="border-bottom p-4 bg-light position-sticky" style="top: 14vh; z-index: 2;">
                    <span class="fw-bold fs-4 d-flex gap-3"><img id="toggle-sidebar" role="button"
                            src="../../assets/icons/menu.svg" alt="">Semua Pesanan</span>
                </nav>
                <div class="container-fluid border px-5">
                    <!-- main header -->
                    <div class="row">
                        <div class="d-flex align-items-center justify-content-between mt-4 p-0" style="z-index: 1;">
                            <a href="booking.php"
                                class="nav-link p-0  p-2 d-flex align-items-center bg-light gap-2 rounded fw-bold"
                                style="border: 1px solid #2E5B7A; color: #2E5B7A;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left-circle"><circle cx="12" cy="12" r="10"/><polyline points="12 8 8 12 12 16"/><line x1="16" y1="12" x2="8" y2="12"/></svg>kembali
                            </a>
                        </div>
                    </div>
                    <!-- main header end -->
                    <br>
                    <div class="row overflow-hidden rounded" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
                        <!-- table area -->
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col" class="py-3">ID Booking</th>
                                    <th scope="col" class="py-3">Nama pelanggan</th>
                                    <th scope="col" class="py-3">Jadwal booking</th>
                                    <th scope="col" class="py-3">paket</th>
                                    <th scope="col" class="py-3">kategori</th>
                                    <th scope="col" class="py-3">Harga</th>
                                    <th scope="col" class="py-3">action</th>
                                </tr>
                            </thead>
                            <tbody id="elementContainer">
                            <?php foreach($result as $booking): ?>
                                <tr class="element">
                                    <td class="order-id-data"><?=$booking['id_booking']?></td>
                                    <td class="product-name-data"><?=$booking['full_name']?></td>
                                    <td class="costumer-name-data"><?=$booking['tgl']?>/<?=$booking['bulan']?>/2024</p></td></td>
                                    <td class="order-data-data"><?=$booking['nama_paket']?></td>
                                    <td class="order-data-data"><?=$booking['jenis_hewan']?></td>
                                    <td class="price-data"><?=formatCurrency($booking['harga'])?></td>
                                    <td
                                        class="action text-center d-flex align-items-center justify-content-center gap-3">
                                        <a href="" class="text-light bg-success textDisplay" data-bs-toggle="modal"
                                            data-bs-target="#staticBackdrop<?=$booking['id_booking']?>"><?=$booking['status']?></a>
                                    </td>
                                </tr>
                                <div class="modal fade" id="staticBackdrop<?=$booking['id_booking']?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="staticBackdropLabel">Detail Pesanan</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body row gx-4 fw-bold">
                            <p class="col-md-6 text-secondary">ID Booking</p>
                            <p class="col-md-6"><?=$booking['id_booking']?></p>
                            <p class="col-md-6 text-secondary">Nama Pelanggan</p>
                            <p class="col-md-6"><?=$booking['full_name']?></p>
                            <p class="col-md-6 text-secondary">Paket</p>
                            <p class="col-md-6"><?=$booking['nama_paket']?></p>
                            <p class="col-md-6 text-secondary">Ketgori</p>
                            <p class="col-md-6"><?=$booking['jenis_hewan']?></p>
                            <p class="col-md-6 text-secondary">Jadwal Booking</p>
                            <p class="col-md-6"><?=$booking['tgl']?>/<?=$booking['bulan']?>/2024</p>
                            <p class="col-md-6 text-secondary">Alamat</p>
                            <p class="col-md-6"><?=$booking['alamat']?></p>
                        </div>
                        <div class="modal-footer d-flex justify-content-center">
                            <span class=" text-center text-light p-2 w-100 rounded bg-success textDisplay"><?=$booking['status']?></span>
                        </div>
                    </div>
                </div>
            </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- table area end -->
                    </div>
                </div>
            </div>
            <!-- main content end -->
            

        </div>
    </div>
</body>
</div>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/script.js"></script>
<script>
    adminSidebarToggle();
    // duplicateElement(15);
    function displayColor(displayText) {
        const text = displayText.textContent.toLowerCase();
        if (text === 'aktif') {
            displayText.classList.add('bg-success')
        } else if (text === 'ditolak') {
            displayText.classList.add('bg-danger')
        } else {
            displayText.classList.add('warning')
        }
    }

    const textDisplay = document.querySelectorAll('.textDisplay');
        textDisplay.forEach(text => {
            displayColor(text);
        });
</script>
</body>

</html>