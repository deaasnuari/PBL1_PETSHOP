<?php
// nama file: [user_dashboard.php]
//deskripsi: halaman dashboard user
// dibuat oleh: [front-end setya pramudiya hakim[3312411030] dan fatra syahreza[3312411031] dan back-end[fatra syahreza]]
//tgl dibuat: 9/12-28/12

include "../../config/koneksi.php";
session_start();
   
$sql = "SELECT * FROM users";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);


if (isset($_POST['cari'])) {
    $keyword = $_POST['keyword'];
    // echo "ada";

    // Menyiapkan query dengan parameter yang dipersiapkan
    $query = "SELECT * FROM users WHERE(
                id LIKE '%$keyword%' OR
                full_name LIKE '%$keyword%' OR
                no_hp LIKE '%$keyword%' OR
                tgl_terdaftar LIKE '%$keyword%' OR
                username LIKE '%$keyword%')";

    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($result) < 1) {
        echo "<script>alert('tidak ada  data yang cocok')</script>";
    }
}



?>
 



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Produk</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap/bootstrap.min.css">
    <!-- costume styling -->
    <style>
        #sidebar.toggled {
            margin-left: -20vw;
        }

        #main-content.toggled {
            margin-left: 0;
        }

        #sidebar,
        #main-content {
            transition: all .3s ease;
        }

        a {
            text-decoration: none;
            color: black;
        }

        .link {
            border-bottom: 2px solid transparent;
            padding: 1rem 0 1rem 1rem;
            transition: .2s ease;
            border-bottom-left-radius: 12px;
        }

        .link:hover {
            padding-left: 1.5rem;
        }

        .link:last-child {
            border: none;
        }

        .active {
            border-bottom: 2px solid #2E5B7A;
            padding-left: 1.5rem;
            font-weight: bold;
            color: #2E5B7A;
        }

        thead th {
            text-align: center;
            vertical-align: middle;
            text-transform: capitalize;
        }

        tbody>tr>td {
            text-align: center;
            vertical-align: middle;
            height: 3.5rem;
        }

        .action>a {
            /* color: white; */
            padding: 5px 1rem;
            font-size: .8rem;
            border-radius: 5px;
            text-transform: capitalize;
        }
    </style>
    <!-- costume styling end -->
</head>

<body style="background-color: #eeeeee;">
    <!-- header -->
    <div class="container-fluid position-sticky top-0" style="height: 14vh; z-index: 2;">
        <div class="row header h-100" style="background-color: #2E5B7A;">
            <div class="d-flex align-items-center gap-2 text-light">
                <img src="../../assets/images/miawoof-logo.jpg" style="width: 4rem" ; class="rounded-circle py-2">
                <span class="fw-bold fs-3">MiaWoof Petshop</span>
            </div>
        </div>
    </div>
    <!-- header end -->
    <div class="container-fluid p-0">
        <div class="d-flex p-0">
            <!-- sidebar -->
            <nav id="sidebar" class="sidebar border d-flex flex-column bg-light position-sticky"
                style="width: 20vw; height: calc(100vh - 14vh); top: 14vh; z-index: 2;">
                <div class="text-center m-3 mt-5">
                    <img src="../..//assets/icons/user.svg" alt="MiaWoof Petshop Logo" style="width: 80px;"
                        class="border border-dark rounded-circle">
                    <p class="fs-5 fw-bold m-0">Admin</p>
                </div>
                <a href="index.php" class="link">Dashboard</a>
                <a href="product_dashboard.php" class="link">Produk</a>
                <a href="pesanan.php" class="link">Pesanan</a>
                <a href="grooming_dashboard.php" class="link">Grooming</a>
                <a href="user_dashboard.php" class="link active">Data User</a>
                <a href="../logout.php" class="link mt-auto d-flex gap-2">
                    <img src="../../assets/icons/log-out.svg" width="18px" alt="">Logout
                </a>
            </nav>
            <!-- sidebar end -->

            <!-- main content -->
            <div id="main-content" class="container-fluid p-0">
                <nav class="border-bottom p-4 bg-light position-sticky" style="top: 14vh; z-index: 2;">
                    <span class="fw-bold fs-4 d-flex gap-3"><img id="toggle-sidebar" role="button"
                            src="../../assets/icons/menu.svg" alt="">Stock Produk</span>
                </nav>
                <div class="container-fluid border px-5">
                    <!-- main header -->
                    <div class="row">
                        <div class="d-flex align-items-center mt-4 p-0" style="z-index: 1;">
                            <a href="tambah_user.php" class="nav-link p-0  p-2 d-flex bg-light gap-2 rounded fw-bold"
                                    style="border: 1px solid #2E5B7A; color: #2E5B7A;"><i><svg
                                            xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                            fill="none" stroke="#2E5B7A" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round" class="feather feather-plus-circle d-flex">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <line x1="12" y1="8" x2="12" y2="16"></line>
                                            <line x1="8" y1="12" x2="16" y2="12"></line>
                                        </svg></i>Tambah Item</a>
                                        <form action="user_dashboard.php" method="POST" class="input-group d-flex w-25 ms-auto rounded overflow-hidden">
                                <span class="input-group-text" id="addon-wrapping"><img
                                        src="../../assets/icons/search.svg" width="18px" alt=""></span>
                                <input type="text" name="keyword" class="form-control" placeholder="cari produk.."
                                    aria-label="Username" aria-describedby="addon-wrapping">
                                <input type="hidden" name="cari">
                            </form>
                            
                        </div>
                    </div>
                    <!-- main header end -->
                    <br>
                    <div class="row overflow-hidden rounded" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
                        <!-- table area -->
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col" class="py-3">ID User</th>
                                    <th scope="col" class="py-3">Nama</th>
                                    <th scope="col" class="py-3">No. handphone</th>
                                    <th scope="col" class="py-3">tanggal terdaftar</th>
                                    <th scope="col" class="py-3">username</th>
                                    <th scope="col" class="py-3">role</th>
                                    <th scope="col" class="py-3">action</th>
                                </tr>
                            </thead>
                            <tbody id="elementContainer">
                            <?php foreach ( $result as $duser)   :  ?>
                                <tr class="element">
                                    <td><?= $duser["id"]; ?></td>
                                    <td><?= $duser["full_name"]; ?></td>
                                    <td><?= $duser["no_hp"]; ?></td>
                                    <td><?= $duser["tgl_terdaftar"]; ?></td>
                                    <td><?= $duser["username"]; ?></td>
                                    <td><?= $duser["role"]; ?></td>
                                    <td
                                        class="action text-center d-flex align-items-center justify-content-center gap-3">
                                        <a href="" class="text-light bg-primary" data-bs-toggle="modal"
                                            data-bs-target="#staticBackdrop<?= $duser["id"]; ?>"  class="text-light bg-primary">Lihat</a>
                                        <a href="tambah_user.php?edit=<?= $duser["id"]; ?>" class="text-light bg-warning">edit</a>
                                        <a href="../../controller/adminController.php?hapus_user=<?= $duser['id'];?>" class="text-light bg-danger">hapus</a>
                                    </td>
                                    
                                </tr>
                                <div class="modal fade" id="staticBackdrop<?= $duser["id"]; ?>" data-bs-backdrop="static" data-bs-keyboard="false"
                            tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Detail Pesanan</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body gx-4">
                                        <div class="row row-gap-3 justify-content-between">
                                            <div class="d-flex flex-column col-6">
                                                <span>User ID</span>
                                                <span class="fw-bold text-dark"><?= $duser["id"]; ?></span>
                                            </div>
                                            <div class="d-flex flex-column col-6">
                                                <span>Nama</span>
                                                <span class="fw-bold text-dark"><?= $duser["full_name"]; ?></span>
                                            </div>
                                            <div class="d-flex flex-column col-6">
                                                <span>No. handphone</span>
                                                <span class="fw-bold text-dark"><?= $duser["no_hp"]; ?></span>
                                            </div>
                                            <div class="d-flex flex-column col-6">
                                                <span>Email</span>
                                                <span class="fw-bold text-dark"><?= $duser["email"]; ?></span>
                                            </div>
                                            <div class="d-flex flex-column col-6">
                                                <span>username</span>
                                                <span class="fw-bold text-dark"><?= $duser["username"]; ?></span>
                                            </div>
                                            <div class="d-flex flex-column col-6">
                                                <span>Alamat</span>
                                                <span class="fw-bold text-dark"><?= $duser["alamat"]; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- table area end -->

                         

                        

                         

                            <!-- main content end -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- main content end -->
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/script.js"></script>
<script>
    adminSidebarToggle();
    <?php
        if(isset($_SESSION['success'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['success']); ?>",
                icon: "success",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['success']); } ?>

        <?php
        if (isset($_SESSION['failed'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['failed']); ?>",
                icon: "error",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['failed']); } ?>
</script>
</body>




</html>