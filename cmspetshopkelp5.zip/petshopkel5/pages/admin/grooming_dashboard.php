<?php
//nama file: [groomingdashboard.php]
//deskripsi: file ini digunakan untuk mengelola bagian grooming
//dibuat oleh: [front-end dn back-end christian marcelino[3312411008] 
//tgl dibut: 9/12-28/12

// Menghubungkan file koneksi ke database dan fungsi tambahan
include "../../config/koneksi.php";
include "../../controller/function.php";

// Logika untuk filter berdasarkan jenis hewan
if(isset($_GET['kucing'])) {
     // Query untuk mengambil data paket grooming untuk kategori kucing
    $sql = "SELECT * FROM paket_grooming WHERE jenis_hewan = 'kucing'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchALL(PDO::FETCH_ASSOC);
} elseif(isset($_GET['anjing'])) {
    // Query untuk mengambil data paket grooming untuk kategori anjing
    $sql = "SELECT * FROM paket_grooming WHERE jenis_hewan = 'anjing'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchALL(PDO::FETCH_ASSOC);
} else {
    // Query untuk mengambil semua data paket grooming tanpa filter
    $sql = "SELECT * FROM paket_grooming";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchALL(PDO::FETCH_ASSOC);
}


?>  


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>grooming dashboard</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap/bootstrap.min.css">
    <!-- costume styling -->
    <style>
        #sidebar.toggled {
            margin-left: -20vw;
        }

        #main-content.toggled {
            margin-left: 0;
        }

        #sidebar,
        #main-content {
            transition: all .3s ease;
        }

        a {
            text-decoration: none;
            color: black;
        }

        .link {
            border-bottom: 2px solid transparent;
            padding: 1rem 0 1rem 1rem;
            transition: .2s ease;
            border-bottom-left-radius: 12px;
        }

        .link:hover {
            padding-left: 1.5rem;
        }

        .link:last-child {
            border: none;
        }

        .active {
            border-bottom: 2px solid #2E5B7A;
            padding-left: 1.5rem;
            font-weight: bold;
            color: #2E5B7A;
        }

        thead th {
            text-align: center;
            vertical-align: middle;
            text-transform: capitalize;
        }

        tbody>tr>td {
            text-align: center;
            vertical-align: middle;
            height: 3.5rem;
        }

        .action>a {
            /* color: white; */
            padding: 5px 1rem;
            font-size: .8rem;
            border-radius: 5px;
            text-transform: capitalize;
        }

        .filter-item {
            color: #2E5B7A;
        }

        .costume-shadow {
            box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
        }
    </style>
    <!-- costume styling end -->
</head>

<body style="background-color: #eeeeee;">
    <!-- header -->
    <div class="container-fluid position-sticky top-0" style="height: 14vh; z-index: 2;">
        <div class="row header h-100" style="background-color: #2E5B7A;">
            <div class="d-flex align-items-center gap-2 text-light">
                <img src="../../assets/images/miawoof-logo.jpg" style="width: 4rem" ; class="rounded-circle py-2">
                <span class="fw-bold fs-3">MiaWoof Petshop</span>
            </div>
        </div>
    </div>
    <!-- header end -->
    <div class="container-fluid p-0">
        <div class="d-flex p-0">
            <!-- sidebar -->
            <nav id="sidebar" class="sidebar border d-flex flex-column bg-light position-sticky"
                style="width: 20vw; height: calc(100vh - 14vh); top: 14vh; z-index: 2;">
                <div class="text-center m-3 mt-5">
                    <img src="../..//assets/icons/user.svg" alt="MiaWoof Petshop Logo" style="width: 80px;"
                        class="border border-dark rounded-circle">
                    <p class="fs-5 fw-bold m-0">Admin</p>
                </div>
                <a href="index.php" class="link">Dashboard</a>
                <a href="product_dashboard.php" class="link">Produk</a>
                <a href="pesanan.php" class="link">Pesanan</a>
                <a href="grooming_dashboard.php" class="link active">Grooming</a>
                <a href="user_dashboard.php" class="link">Data User</a>
                <a href="../logout.php" class="link mt-auto d-flex gap-2">
                    <img src="../../assets/icons/log-out.svg" width="18px" alt="">Logout
                </a>
            </nav>
            <!-- sidebar end -->

            <!-- main content -->
            <div id="main-content" class="container-fluid p-0">
                <!-- main header -->
                <nav class="border-bottom p-4 bg-light position-sticky" style="top: 14vh; z-index: 2;">
                    <span class="fw-bold fs-4 d-flex gap-3"><img id="toggle-sidebar" role="button"
                            src="../../assets/icons/menu.svg" alt="">Grooming</span>
                </nav>
                <!-- main header end -->

                <!-- main -->
                <div class="container-fluid border px-4">
                    <!-- filter & action section -->
                    <div class="row">
                        <div class="d-flex align-items-center justify-content-between py-4">
                            <section class="d-flex gap-4">
                                <a href="grooming_dashboard.php" class="filter-item bg-white py-2 px-4 rounded">Semua</a>
                                <a href="grooming_dashboard.php?kucing" class="filter-item bg-white py-2 px-4 rounded">Kucing</a>
                                <a href="grooming_dashboard.php?anjing" class="filter-item bg-white py-2 px-4 rounded">Anjing</a>
                            </section>
                            <a href="tambah_paket_grooming.php" class="nav-link p-0  p-2 d-flex bg-light gap-2 rounded fw-bold"
                                style="border: 1px solid #2E5B7A; color: #2E5B7A;"><i><svg
                                        xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                        fill="none" stroke="#2E5B7A" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" class="feather feather-plus-circle d-flex">
                                        <circle cx="12" cy="12" r="10"></circle>
                                        <line x1="12" y1="8" x2="12" y2="16"></line>
                                        <line x1="8" y1="12" x2="16" y2="12"></line>
                                    </svg></i>Tambah Item</a>
                        </div>
                    </div>
                    <div class="row">
                        <!-- Daftar Paket Grooming -->
                        <div id="elementContainer" class="d-flex flex-wrap gap-3">
                            <?php foreach($result as $paket): ?>
                            <div class="element card bg-light p-3 flex-grow-1 costume-shadow"
                                style="flex-basis: 200px;">
                                <a href="" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?=$paket['id_paket']?>"
                                    class="fw-bold textDisplay"><?= $paket['nama_paket']?> grooming</a>
                                <cite class="text-dark-emphasis"><?= $paket['jenis_hewan']?></cite>
                                <span><?= formatCurrency($paket['harga']) ?></span>
                                </a>
                            </div>
                            <div class="modal fade" id="staticBackdrop<?=$paket['id_paket']?>" data-bs-backdrop="static"
                                data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
                                aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="staticBackdropLabel">Detail Paket Grooming</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body gx-4">
                                            <div class="row row-gap-3 justify-content-between">
                                                <div class="d-flex flex-column col-12">
                                                    <span>Jenis Paket</span>
                                                    <span class="fw-bold textDisplay"><?= $paket['nama_paket']; ?> grooming</span>
                                                </div>
                                                <div class="d-flex flex-column col-12">
                                                    <span>Kategori</span>
                                                    <span class="fw-bold text-dark"><?= $paket['jenis_hewan']; ?></span>
                                                </div>
                                                <div class="d-flex flex-column col-12">
                                                    <span>Harga</span>
                                                    <span class="fw-bold text-dark"><?= formatCurrency($paket['harga']) ?></span>
                                                </div>
                                                <div class="d-flex flex-column col-12">
                                                    <span>Keterangan grooming</span>
                                                    <span class="fw-bold text-dark"><?= $paket['keterangan_grooming']; ?></span>
                                                </div>
                                            </div>
                                            <br>
                                            <a href="tambah_paket_grooming.php?edit=<?=$paket['id_paket']?>" class="text-light bg-primary py-1 px-5 rounded">Edit</a>
                                            <a href="../../controller/adminController.php?hapus_paket=<?=$paket['id_paket']?>" class="text-light bg-danger py-1 px-5 rounded">hapus</a>
                                        </div> 
                                    </div>
                                </div>
                                <!-- main content end -->
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <!-- main end -->
                </div>
                <!-- main content end -->
            </div>
        </div>
</body>
</div>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/script.js"></script>
<script>
    adminSidebarToggle();
    function displayColor(displayText) {
        const text = displayText.textContent.toLowerCase();
        if (text === 'reguler grooming') {
            displayText.classList.add('text-success')
        } else if (text === 'premium grooming') {
            displayText.classList.add('text-warning')
        }
    }

    const textDisplay = document.querySelectorAll('.textDisplay');
        textDisplay.forEach(text => {
            displayColor(text);
        });
</script>
</body>

</html>