<?php 
//nama file: semua pesanan.php
//deskripsi: menampilkan semua pesanan yang telah dibuat oleh user
//dibuat oleh: [front-end hamdan azmi[3312411004] backend christin marcelino[3312411008]]
include "../../config/koneksi.php";
include "../../controller/function.php";
session_start();

$sql = "SELECT * FROM pesanan ps
        JOIN produk p ON ps.id_produk = p.id_produk
        JOIN users u ON ps.id_pembeli = u.id WHERE status = 'dikirim' OR status = 'ditolak'";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Produk</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap/bootstrap.min.css">
    <!-- costume styling -->
    <style>
        #sidebar.toggled {
            margin-left: -20vw;
        }

        #main-content.toggled {
            margin-left: 0;
        }

        #sidebar,
        #main-content {
            transition: all .3s ease;
        }

        a {
            text-decoration: none;
            color: black;
        }

        .link {
            border-bottom: 2px solid transparent;
            padding: 1rem 0 1rem 1rem;
            transition: .2s ease;
            border-bottom-left-radius: 12px;
        }

        .link:hover {
            padding-left: 1.5rem;
        }

        .link:last-child {
            border: none;
        }

        .active {
            border-bottom: 2px solid #2E5B7A;
            padding-left: 1.5rem;
            font-weight: bold;
            color: #2E5B7A;
        }

        thead th {
            text-align: center;
            vertical-align: middle;
            text-transform: capitalize;
        }

        tbody>tr>td {
            text-align: center;
            vertical-align: middle;
            height: 3.5rem;
        }

        .action>a {
            /* color: white; */
            padding: 5px 1rem;
            font-size: .8rem;
            border-radius: 5px;
            text-transform: capitalize;
        }
    </style>
    <!-- costume styling end -->
</head>

<body style="background-color: #eeeeee;">
    <!-- header -->
    <div class="container-fluid position-sticky top-0" style="height: 14vh; z-index: 2;">
        <div class="row header h-100" style="background-color: #2E5B7A;">
            <div class="d-flex align-items-center gap-2 text-light">
                <img src="../../assets/images/miawoof-logo.jpg" style="width: 4rem" ; class="rounded-circle py-2">
                <span class="fw-bold fs-3">MiaWoof Petshop</span>
            </div>
        </div>
    </div>
    <!-- header end -->
    <div class="container-fluid p-0">
        <div class="d-flex p-0">
            <!-- sidebar -->
            <nav id="sidebar" class="sidebar border d-flex flex-column bg-light position-sticky"
                style="width: 20vw; height: calc(100vh - 14vh); top: 14vh; z-index: 2;">
                <div class="text-center m-3 mt-5">
                    <img src="../..//assets/icons/user.svg" alt="MiaWoof Petshop Logo" style="width: 80px;"
                        class="border border-dark rounded-circle">
                    <p class="fs-5 fw-bold m-0">Admin</p>
                </div>
                <a href="index.php" class="link">Dashboard</a>
                <a href="product_dashboard.php" class="link">Produk</a>
                <a href="pesanan.php" class="link active">Pesanan</a>
                <a href="grooming_dashboard.php" class="link">Grooming</a>
                <a href="user_dashboard.php" class="link">Data User</a>
                <a href="../logout.php" class="link mt-auto d-flex gap-2">
                    <img src="../../assets/icons/log-out.svg" width="18px" alt="">Logout
                </a>
            </nav>
            <!-- sidebar end -->

            <!-- main content -->
            <div id="main-content" class="container-fluid p-0">
                <nav class="border-bottom p-4 bg-light position-sticky" style="top: 14vh; z-index: 2;">
                    <span class="fw-bold fs-4 d-flex gap-3"><img id="toggle-sidebar" role="button"
                            src="../../assets/icons/menu.svg" alt="">Semua Pesanan</span>
                </nav>
                <div class="container-fluid border px-5">
                    <!-- main header -->
                    <div class="row">
                        <div class="d-flex align-items-center justify-content-between mt-4 p-0" style="z-index: 1;">
                            <a href="pesanan_produk.php"
                                class="nav-link p-0  p-2 d-flex align-items-center bg-light gap-2 rounded fw-bold"
                                style="border: 1px solid #2E5B7A; color: #2E5B7A;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-arrow-left-circle">
                                    <circle cx="12" cy="12" r="10" />
                                    <polyline points="12 8 8 12 12 16" />
                                    <line x1="16" y1="12" x2="8" y2="12" />
                                </svg>kembali
                            </a>
                        </div>
                    </div>
                    <!-- main header end -->
                    <br>
                    <div class="row overflow-hidden rounded" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
                        <!-- table area -->
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col" class="py-3">ID Pesanan</th>
                                    <th scope="col" class="py-3">Produk</th>
                                    <th scope="col" class="py-3">Nama pelanggan</th>
                                    <th scope="col" class="py-3">tanggal pesanan</th>
                                    <th scope="col" class="py-3">Harga</th>
                                    <th scope="col" class="py-3">Status</th>
                                </tr>
                            </thead>
                            <tbody id="elementContainer">
                                <?php foreach($result as $pesanan): ?>
                                <tr class="element">
                                    <td class=""><?= $pesanan['id_pesanan']?></td>
                                    <td class="col-3"><?= $pesanan['nama']?></td>
                                    <td class=""><?= $pesanan['full_name'] ?></td>
                                    <td class=""><?= $pesanan['tgl_dibuat']?></td>
                                    <td class=""><?= formatCurrency($pesanan['harga'])?></td>
                                    <td
                                        class="action text-center gap-3">
                                        <a href="" class="text-light bg-success textDisplay" data-bs-toggle="modal"
                                            data-bs-target="#staticBackdrop"><?= $pesanan['status']?></a>
                                    </td>
                                </tr>
                                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static"
                                    data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="staticBackdropLabel">Detail Pesanan
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body row gx-4 fw-bold">
                                                <p class="col-md-6 text-secondary">ID Pesanan</p>
                                                <p class="col-md-6"><?= $pesanan['id_pesanan']?></p>
                                                <p class="col-md-6 text-secondary">Nama Produk</p>
                                                <p class="col-md-6"><?= $pesanan['kategori']?></p>
                                                <p class="col-md-6 text-secondary">Ketegori</p>
                                                <p class="col-md-6">Kucing</p>
                                                <p class="col-md-6 text-secondary">jumlah</p>
                                                <p class="col-md-6"><?= $pesanan['jumlah']?></p>
                                                <p class="col-md-6 text-secondary">Tanggal Pesan</p>
                                                <p class="col-md-6"><?= $pesanan['tgl_pesanan']?></p>
                                                <p class="col-md-6 text-secondary">Expired Produk</p>
                                                <p class="col-md-6"><?= $pesanan['tgl_expired']?></p>
                                                <p class="col-md-6 text-secondary">Pembeli</p>
                                                <p class="col-md-6"><?= $pesanan['full_name']?></p>
                                                <p class="col-md-6 text-secondary">Alamat</p>
                                                <p class="col-md-6"><?= $pesanan['alamat']?></p>
                                            </div>
                                            <div class="modal-footer d-flex justify-content-center">
                                                <span
                                                    class=" text-center text-light p-2 w-100 rounded bg-success">Dikirim</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- table area end -->
                    </div>
                </div>
            </div>
            <!-- main content end -->
        </div>
    </div>
</body>
</div>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../../assets/js/script.js"></script>
<script>
    adminSidebarToggle();
    // duplicateElement(15);
    function displayColor(displayText) {
        const text = displayText.textContent.toLowerCase();
        if (text === 'dibayar') {
            displayText.classList.add('bg-success')
        } else if (text === 'ditolak') {
            displayText.classList.add('bg-danger')
        } else {
            displayText.classList.add('warning')
        }
    }

    const textDisplay = document.querySelectorAll('.textDisplay');
        textDisplay.forEach(text => {
            displayColor(text);
        });
</script>
</body>

</html>