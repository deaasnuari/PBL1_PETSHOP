<?php 
//nama file: booking.php
// deskripsi: file ini untuk menampilkan data booking dan melakukan proses booking
// dibuat oleh: [front-end dan back-en fatra syahreza] [nim: 3312411031]
// tanggal dibuat:[9/12/2024 - 28/12/2024]


// Menghubungkan file konfigurasi dan fungsi
include "../../config/koneksi.php";
include "../../controller/function.php";
session_start();

// Query untuk mendapatkan data booking yang menunggu konfirmasi
$sql = "SELECT * FROM booking bo
        JOIN paket_grooming pg ON pg.id_paket = bo.id_paket
        JOIN users u ON bo.id_costumer = u.id 
        WHERE status = 'menunggu konfirmasi'
        ORDER BY bo.id_booking DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Produk</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap/bootstrap.min.css">
    <!-- costume styling -->
    <style>
        #sidebar.toggled {
            margin-left: -20vw;
        }

        #main-content.toggled {
            margin-left: 0;
        }

        #sidebar,
        #main-content {
            transition: all .3s ease;
        }

        a {
            text-decoration: none;
            color: black;
        }

        .link {
            border-bottom: 2px solid transparent;
            padding: 1rem 0 1rem 1rem;
            transition: .2s ease;
            border-bottom-left-radius: 12px;
        }

        .link:hover {
            padding-left: 1.5rem;
        }

        .link:last-child {
            border: none;
        }

        .active {
            border-bottom: 2px solid #2E5B7A;
            padding-left: 1.5rem;
            font-weight: bold;
            color: #2E5B7A;
        }

        thead th {
            text-align: center;
            vertical-align: middle;
            text-transform: capitalize;
        }

        tbody>tr>td {
            text-align: center;
            vertical-align: middle;
            height: 3.5rem;
        }

        .action>a {
            /* color: white; */
            padding: 5px 1rem;
            font-size: .8rem;
            border-radius: 5px;
            text-transform: capitalize;
        }
    </style>
    <!-- costume styling end -->
</head>

<body style="background-color: #eeeeee;">
    <!-- header -->
    <div class="container-fluid position-sticky top-0" style="height: 14vh; z-index: 2;">
        <div class="row header h-100" style="background-color: #2E5B7A;">
            <div class="d-flex align-items-center gap-2 text-light">
                <img src="../../assets/images/miawoof-logo.jpg" style="width: 4rem" ; class="rounded-circle py-2">
                <span class="fw-bold fs-3">MiaWoof Petshop</span>
            </div>
        </div>
    </div>
    <!-- header end -->

    <div class="container-fluid p-0">
        <div class="d-flex p-0">
            <!-- Sidebar dan Konten Utama -->
            <nav id="sidebar" class="sidebar border d-flex flex-column bg-light position-sticky"
                style="width: 20vw; height: calc(100vh - 14vh); top: 14vh; z-index: 2;">
                <div class="text-center m-3 mt-5">
                    <img src="../..//assets/icons/user.svg" alt="MiaWoof Petshop Logo" style="width: 80px;"
                        class="border border-dark rounded-circle">
                    <p class="fs-5 fw-bold m-0">Admin</p>
                </div>
                <!-- Menu Navigasi -->
                <a href="index.php" class="link">Dashboard</a>
                <a href="product_dashboard.php" class="link">Produk</a>
                <a href="pesanan.php" class="link active">Pesanan</a>
                <a href="grooming_dashboard.php" class="link">Grooming</a>
                <a href="user_dashboard.php" class="link">Data User</a>
                <a href="../logout.php" class="link mt-auto d-flex gap-2">
                    <img src="../../assets/icons/log-out.svg" width="18px" alt="">Logout
                </a>
            </nav>
            <!-- sidebar end -->
        
            <!-- main content -->
            <div id="main-content" class="container-fluid p-0">
                <nav class="border-bottom p-4 bg-light position-sticky" style="top: 14vh; z-index: 2;">
                    <span class="fw-bold fs-4 d-flex gap-3"><img id="toggle-sidebar" role="button"
                            src="../../assets/icons/menu.svg" alt="">Booking</span>
                </nav>
                <!-- Area Data Booking -->
                <div class="container-fluid border px-5">
                    <!-- main header -->
                     <!-- Tombol Riwayat Booking -->
                    <div class="row">
                        <div class="d-flex align-items-center justify-content-between mt-4 p-0" style="z-index: 1;">
                            <a href="riwayat_booking.php"
                                class="nav-link p-0  p-2 d-flex align-items-center bg-light gap-2 rounded fw-bold"
                                style="border: 1px solid #2E5B7A; color: #2E5B7A;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 31 29"
                                    fill="none">
                                    <path
                                        d="M23.5625 3.5625H30.2812V28.7188H0.71875V3.5625H7.4375V5.75H23.5625V3.5625ZM6.09375 14.5H24.9062V12.3125H6.09375V14.5ZM6.09375 23.25H24.9062V21.0625H6.09375V23.25ZM10.125 3.5625V0.28125H20.875V3.5625H10.125Z"
                                        fill="#2E5B7A" />
                                </svg>Riwayat Booking
                            </a>
                        </div>
                    </div>
                    <!-- main header end -->
                    <br>
                    <div class="row overflow-hidden rounded" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
                        <!-- table area -->
                        <table class="table table-striped">
                            <thead>
                                
                                <tr>
                                    <th scope="col" class="py-3">ID Booking</th>
                                    <th scope="col" class="py-3">Nama pelanggan</th>
                                    <th scope="col" class="py-3">Jadwal booking</th>
                                    <th scope="col" class="py-3">Paket</th>
                                    <th scope="col" class="py-3">Kategori</th>
                                    <th scope="col" class="py-3">harga</th>
                                    <th scope="col" class="py-3">action</th>
                                </tr>
                            </thead>
                            <tbody id="elementContainer">
                                <!-- Iterasi data booking -->
                            <?php foreach($result as $booking): ?>
                                <tr class="element">
                                    <td class="order-id-data"><?=$booking['id_booking']?></td>
                                    <td class="product-name-data"><?=$booking['full_name']?></td>
                                    <td class="costumer-name-data"><?=$booking['tgl']?>/<?=$booking['bulan']?>/2024</p></td>
                                    <td class="order-data-data"><?=$booking['nama_paket']?></td>
                                    <td class="order-data-data"><?=$booking['jenis_hewan']?></td>
                                    <td class="price-data"><?= formatCurrency($booking['harga'])?></td>
                                    <td
                                        class="action text-center d-flex align-items-center justify-content-center gap-3">
                                        <a href="" class="text-light bg-primary" data-bs-toggle="modal"
                                            data-bs-target="#staticBackdrop">Lihat</a>
                                        <a href="../../controller/adminController.php?confirmBooking=<?=$booking['id_booking']?>" class="text-light bg-success">Terima</a>
                                        <a href="../../controller/adminController.php?rejectBooking=<?=$booking['id_booking']?>" class="text-light bg-danger">Tolak</a>
                                    </td>
                                </tr>
                                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static"
                                    data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="staticBackdropLabel">Detail Pesanan
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body row gx-4 fw-bold">
                                                <p class="col-md-6 text-secondary">ID Booking</p>
                                                <p class="col-md-6"><?=$booking['id_booking']?></p>
                                                <p class="col-md-6 text-secondary">Nama Pelanggan</p>
                                                <p class="col-md-6"><?=$booking['full_name']?></p>
                                                <p class="col-md-6 text-secondary">Paket</p>
                                                <p class="col-md-6"><?=$booking['nama_paket']?></p>
                                                <p class="col-md-6 text-secondary">Ketgori</p>
                                                <p class="col-md-6"><?=$booking['jenis_hewan']?></p>
                                                <p class="col-md-6 text-secondary">Jadwal Booking</p>
                                                <p class="col-md-6"><?=$booking['tgl']?>/<?=$booking['bulan']?>/2024</p>
                                                <p class="col-md-6 text-secondary">Alamat</p>
                                                <p class="col-md-6"><?=$booking['alamat']?></p>
                                            </div>
                                            <div class="modal-footer d-flex justify-content-center">
                                                <p class="fs-3 fw-bold p-0 m-0"><?= formatCurrency($booking['harga'])?></p>
                                                <span
                                                    class=" text-center text-light p-2 w-100 rounded bg-warning bg-success">Dipesan</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>

                            </tbody>
                        </table>
                        <!-- table area end -->
                    </div>
                </div>
            </div>
            <!-- main content end -->

        </div>
    </div>
</body>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/script.js"></script>
<script>
    adminSidebarToggle();
    // duplicateElement(5);
    <?php
        if(isset($_SESSION['success'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['success']); ?>",
                icon: "success",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['success']); } ?>
            
        <?php
        if (isset($_SESSION['failed'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['failed']); ?>",
                icon: "error",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['failed']); } ?>
        </script>
</script>
</body>

</html>