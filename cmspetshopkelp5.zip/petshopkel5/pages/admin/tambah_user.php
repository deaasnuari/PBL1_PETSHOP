<?php 
//nama file: tambah user.php
//deskripsi: menambahkan user baru ke database
//dibuat oleh: [front-end setya pramudiya hakim [3312411030] dan back-end fatra syhreza[3312411031]]
//tgl dibuat: 9/12-28/12

include "../../config/koneksi.php";
session_start();

if(!isset($_GET['edit'])) {
    $id_user = "";
    $nama_user = "";
    $password = "";
    $username = "";
    $email = "";
    $telepon = "";
    $alamat = "";


} else {
    $id_user = $_GET['edit'];
    $query = "SELECT * FROM users WHERE id = $id_user";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $nama_user = $user['full_name'];
    $username = $user['username'];
    $password = $user['password'];
    $email = $user['email'];
    $telepon = $user['no_hp'];
    $alamat = $user['alamat'];
    
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data User</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap/bootstrap.min.css">
    <!-- costume styling -->
    <style>
    #sidebar.toggled {
        margin-left: -20vw;
    }

    #main-content.toggled {
        margin-left: 0;
    }

    #sidebar,
    #main-content {
        transition: all .3s ease;
    }

    a {
        text-decoration: none;
        color: black;
    }

    .link {
        border-bottom: 2px solid transparent;
        padding: 1rem 0 1rem 1rem;
        transition: .2s ease;
        border-bottom-left-radius: 12px;
    }

    .link:hover {
        padding-left: 1.5rem;
    }

    .link:last-child {
        border: none;
    }

    .active {
        border-bottom: 2px solid #2E5B7A;
        padding-left: 1.5rem;
        font-weight: bold;
        color: #2E5B7A;
    }

    .costume-shadow {
        box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
    }
    </style>
    <!-- costume styling end -->
</head>

<body style="background-color: #eeeeee;">
    <!-- header -->
    <div class="container-fluid position-sticky top-0" style="height: 14vh; z-index: 2;">
        <div class="row header h-100" style="background-color: #2E5B7A;">
            <div class="d-flex align-items-center gap-2 text-light">
                <img src="../../assets/images/miawoof-logo.jpg" style="width: 4rem" ; class="rounded-circle py-2">
                <span class="fw-bold fs-3">MiaWoof Petshop</span>
            </div>
        </div>
    </div>
    <!-- header end -->
    <div class="container-fluid p-0">
        <div class="d-flex p-0">
            <!-- sidebar -->
            <nav id="sidebar" class="sidebar border d-flex flex-column bg-light position-sticky"
                style="width: 20vw; height: calc(100vh - 14vh); top: 14vh; z-index: 2;">
                <div class="text-center m-3 mt-5">
                    <img src="../..//assets/icons/user.svg" alt="MiaWoof Petshop Logo" style="width: 80px;"
                        class="border border-dark rounded-circle">
                    <p class="fs-5 fw-bold m-0">Admin</p>
                </div>
                <a href="index.html" class="link">Dashboard</a>
                <a href="product_dashboard.html" class="link">Produk</a>
                <a href="pesanan.html" class="link">Pesanan</a>
                <a href="grooming_dashboard.html" class="link">Grooming</a>
                <a href="user_dashboard.html" class="link active">Data User</a>
                <a href="../logout.php" class="link mt-auto d-flex gap-2">
                    <img src="../../assets/icons/log-out.svg" width="18px" alt="">Logout
                </a>
            </nav>
            <!-- sidebar end -->

            <!-- main content -->
            <div id="main-content" class="container-fluid p-0">
                <nav class="border-bottom p-4 bg-light position-sticky" style="top: 14vh; z-index: 2;">
                    <span class="fw-bold fs-4 d-flex gap-3"><img id="toggle-sidebar" role="button"
                            src="../../assets/icons/menu.svg" alt=""><?php if (isset($_GET['edit'])) {echo "Edit User";} else {echo "Tambah User";} ?></span>
                </nav>
                <div class="container-fluid border px-4">
                    <div class="bg-white p-4 rounded my-4 costume-shadow">
                        <form method="POST" action="../../controller/adminController.php" enctype="multipart/form-data">
                            <input type="hidden" name="id_user" value="<?=$id_user?>">
                            <div class="mb-3">
                                <label for="nama-produk" class="form-label">Nama</label>
                                <input type="text" name="full_name" value="<?=$nama_user?>" class="form-control border border-secondary border border-secondary"
                                    id="nama-produk">
                            </div>
                            <div class="row">
                                <div class="mb-3 col-8">
                                    <label for="harga" class="form-label">Username</label>
                                    <input type="text" name="username" value="<?= $username?>" class="form-control border border-secondary" id="harga">
                                </div>
                                <div class="mb-3 col-4">
                                    <label for="stock" class="form-label">Password</label>
                                    <input type="text" name="password" value="<?= $password?>" class="form-control border border-secondary" id="stock">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="tgl_produksi" class="form-label">email</label>
                                    <input type="text" name="email" value="<?= $email?>" class="form-control border border-secondary" id="tgl_produksi"
                                        value="">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="tanggal-kadaluarsa" class="form-label">Telepon</label>
                                    <input type="text" name="no_hp" value="<?= $telepon?>" class="form-control border border-secondary" id="tanggal-kadaluarsa">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="keterangan-paket">Alamat</label>
                                <textarea name="alamat" id="keterangan-paket" 
                                class="form-control border border-secondary"><?= $alamat ?></textarea>
                            </div>
                            <div class="d-flex justify-content-end gap-2 border-top pt-3">
                                <?php if(isset($_GET['edit'])) { ?>
                                <button type="submit" name="edit_user" class="btn btn-primary px-4 border-0"
                                    style="background-color: #2E5B7A;">Perbarui</button>
                                <?php } else { ?>
                                <button type="submit" name="tambah_user" class="btn btn-primary px-4 border-0"
                                    style="background-color: #2E5B7A;">Tambahkan</button>
                                <?php } ?>
                                <button type="button" onclick="location.href='user_dashboard.php'"
                                    class="btn btn-secondary px-4">Batal</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- main content end -->
        </div>
    </div>
</body>
</div>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/script.js"></script>
<script>
adminSidebarToggle();
duplicateElement(5);
</script>
</body>

</html>