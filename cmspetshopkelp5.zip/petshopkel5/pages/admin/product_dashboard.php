<?php 
// nama file: [produk dashboard.php]
//deskripsi: [file ini berfungsi untuk menampilkan data produk yang ada di database]
//dibuat oleh: [front-end dea asnuari[3312411001], back-end dea asnuari dan hamdan azmi [3312411004] ]
//tnggal dibuat: 9/12-28/12

include "../../config/koneksi.php";
include "../../controller/function.php";
session_start();

// if(!isset[$_SESSION['id']]) {
//     header("Location: ../logout.php");
// } else {
    // $id_admin = $_SESSION['id'];
    $id_admin = 1;
    
    $sql = "SELECT * FROM produk";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
// }

if (isset($_POST['cari'])) {
    $keyword = $_POST['keyword'];
    // echo "ada";

    // Menyiapkan query dengan parameter yang dipersiapkan
    $query = "SELECT * FROM produk WHERE(
                nama LIKE '%$keyword%' OR
                kategori LIKE '%$keyword%' OR
                stock LIKE '%$keyword%' OR
                tgl_dibuat LIKE '%$keyword%' OR
                tgl_expired LIKE '%$keyword%')";
    
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($result) < 1) {
        echo "<script>alert('tidak ada  data yang cocok')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Produk</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap/bootstrap.min.css">
    <!-- costume styling -->
    <style>
    #sidebar.toggled {
        margin-left: -20vw;
    }

    #main-content.toggled {
        margin-left: 0;
    }

    #sidebar,
    #main-content {
        transition: all .3s ease;
    }

    a {
        text-decoration: none;
        color: black;
    }

    .link {
        border-bottom: 2px solid transparent;
        padding: 1rem 0 1rem 1rem;
        transition: .2s ease;
        border-bottom-left-radius: 12px;
    }

    .link:hover {
        padding-left: 1.5rem;
    }

    .link:last-child {
        border: none;
    }

    .active {
        border-bottom: 2px solid #2E5B7A;
        padding-left: 1.5rem;
        font-weight: bold;
        color: #2E5B7A;
    }

    thead th {
        text-align: center;
        vertical-align: middle;
        text-transform: capitalize;
    }

    tbody>tr>td {
        text-align: center;
        vertical-align: middle;
        height: 3.5rem;
    }

    .action>a {
        /* color: white; */
        padding: 5px 1rem;
        font-size: .8rem;
        border-radius: 5px;
        text-transform: capitalize;
    }
    </style>
    <!-- costume styling end -->
</head>

<body style="background-color: #eeeeee;">
    <!-- header -->
    <div class="container-fluid position-sticky top-0" style="height: 14vh; z-index: 2;">
        <div class="row header h-100" style="background-color: #2E5B7A;">
            <div class="d-flex align-items-center gap-2 text-light">
                <img src="../../assets/images/miawoof-logo.jpg" style="width: 4rem" ; class="rounded-circle py-2">
                <span class="fw-bold fs-3">MiaWoof Petshop</span>
            </div>
        </div>
    </div>
    <!-- header end -->
    <div class="container-fluid p-0">
        <div class="d-flex p-0">
            <!-- sidebar -->
            <nav id="sidebar" class="sidebar border d-flex flex-column bg-light position-sticky"
                style="width: 20vw; height: calc(100vh - 14vh); top: 14vh; z-index: 2;">
                <div class="text-center m-3 mt-5">
                    <img src="../..//assets/icons/user.svg" alt="MiaWoof Petshop Logo" style="width: 80px;"
                        class="border border-dark rounded-circle">
                    <p class="fs-5 fw-bold m-0">Admin</p>
                </div>
                <a href="index.php" class="link">Dashboard</a>
                <a href="product_dashboard.php" class="link active">Produk</a>
                <a href="pesanan.php" class="link">Pesanan</a>
                <a href="grooming_dashboard.php" class="link">Grooming</a>
                <a href="user_dashboard.php" class="link">Data User</a>
                <a href="../logout.php" class="link mt-auto d-flex gap-2">
                    <img src="../../assets/icons/log-out.svg" width="18px" alt="">Logout
                </a>
            </nav>
            <!-- sidebar end -->

            <!-- main content -->
            <div id="main-content" class="container-fluid p-0">
                <nav class="border-bottom p-4 bg-light position-sticky" style="top: 14vh; z-index: 2;">
                    <span class="fw-bold fs-4 d-flex gap-3"><img id="toggle-sidebar" role="button"
                            src="../../assets/icons/menu.svg" alt="">Stock Produk</span>
                </nav>
                <div class="container-fluid border px-5">
                    <!-- main header -->
                    <div class="row">
                        <div class="d-flex align-items-center justify-content-between mt-4 p-0" style="z-index: 1;">
                            <a href="tambah_produk.php" class="nav-link p-0  p-2 d-flex bg-light gap-2 rounded fw-bold"
                                style="border: 1px solid #2E5B7A; color: #2E5B7A;"><i><svg
                                        xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                        fill="none" stroke="#2E5B7A" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" class="feather feather-plus-circle d-flex">
                                        <circle cx="12" cy="12" r="10"></circle>
                                        <line x1="12" y1="8" x2="12" y2="16"></line>
                                        <line x1="8" y1="12" x2="16" y2="12"></line>
                                    </svg></i>Tambah Item</a>
                            <form action="product_dashboard.php" method="POST" class="input-group d-flex w-25">
                                <span class="input-group-text" id="addon-wrapping"><img
                                        src="../../assets/icons/search.svg" width="18px" alt=""></span>
                                <input type="text" name="keyword" class="form-control" placeholder="cari produk.."
                                    aria-label="Username" aria-describedby="addon-wrapping">
                                <input type="hidden" name="cari">
                            </form>
                        </div>
                    </div>
                    <!-- main header end -->
                    <br>
                    <div class="row overflow-hidden rounded" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
                        <!-- table area -->
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col" class="py-3">ID Produk</th>
                                    <th scope="col" class="py-3">nama</th>
                                    <th scope="col" class="py-3">tgl kadaluarsa</th>
                                    <th scope="col" class="py-3">harga</th>
                                    <th scope="col" class="py-3">stock</th>
                                    <th scope="col" class="py-3">action</th>
                                </tr>
                            </thead>
                            <tbody id="elementContainer">
                                <?php foreach($result as $produk): ?>
                                <tr class="element">
                                    <td>
                                        <?= $produk['id_produk'] ?>
                                    </td>
                                    <td>
                                        <?= $produk['nama'] ?>
                                    </td>
                                    <td>
                                        <?= $produk['tgl_expired'] ?>
                                    </td>
                                    <td>
                                        <?= formatCurrency($produk['harga']) ?>
                                    </td>
                                    <td>
                                        <?= $produk['stock'] ?>
                                    </td>
                                    <td
                                        class="action text-center d-flex align-items-center justify-content-center gap-3">
                                        <a href="" class="text-light bg-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?= $produk['id_produk']?>" class="text-light bg-primary">Lihat</a>
                                        <a href="tambah_produk.php?edit=<?= $produk['id_produk'];?>"
                                        class="text-light bg-warning">edit</a>
                                        <a href="../../controller/adminController.php?hapus=<?= $produk['id_produk'];?>" class="text-light bg-danger openPopUp">hapus</a>
                                        
                                    </td>
                                </tr>
                                <div class="modal fade" id="staticBackdrop<?= $produk['id_produk']?>" data-bs-backdrop="static"
                                    data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="staticBackdropLabel">Detail Pesanan
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body gx-4 fw-bold">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <img src="../../assets/product_item/<?= $produk['gambar']?>" width="100px"
                                                            alt="">
                                                    </div>
                                                    <div class="row col-9 fw-bold">
                                                        <p class="col-7 text-secondary">ID Produk</p>
                                                        <p class="col-5">
                                                            <?= $produk['id_produk'] ?>
                                                        </p>
                                                        <p class="col-7 text-secondary">Nama Produk</p>
                                                        <p class="col-5">
                                                            <?= $produk['nama'] ?>
                                                        </p>
                                                        <p class="col-7 text-secondary">kategori</p>
                                                        <p class="col-5">
                                                            <?= $produk['kategori'] ?>
                                                        </p>
                                                        <p class="col-7 text-secondary">Harga</p>
                                                        <p class="col-5">
                                                            <?= formatCurrency($produk['harga']) ?>
                                                        </p>
                                                        <p class="col-7 text-secondary">Stock</p>
                                                        <p class="col-5">
                                                            <?= $produk['stock'] ?>
                                                        </p>
                                                        <p class="col-7 text-secondary">Tanggal Produksi</p>
                                                        <p class="col-5">
                                                            <?= $produk['tgl_dibuat'] ?>
                                                        </p>
                                                        <p class="col-7 text-secondary">Tanggal kadaluarsa</p>
                                                        <p class="col-5">
                                                            <?= $produk['tgl_expired'] ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- main content end -->
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- table area end -->
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="../../assets/js/bootstrap.bundle.min.js"></script>
        <script src="../../assets/js/script.js"></script>
        <script>
        adminSidebarToggle();
        //duplicateElement(5);

        //ini  untuk popup dialog
        const openPopUp = document.querySelectorAll('.openPopUp')
        openPopUp.forEach(openPopUp => {
            openPopUp.addEventListener('click', (event) => {
                event.preventDefault()
                const bookingId = openPopUp.getAttribute('data-id')
                Swal.fire({
                    title: "Hapus data produk ini?",
                    text: "kamu tidak akan dapat mengembalikan ini!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#2E5B7A",
                    cancelButtonColor: "#DD332A",
                    confirmButtonText: "Ya, Hapus!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        location.href = `../../controller/adminController.php?hapus=<?= $produk['id_produk']?>`
                    }
                });
            })
        });

        <?php
        if(isset($_SESSION['success'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['success']); ?>",
                icon: "success",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['success']); } ?>
            
        <?php
        if (isset($_SESSION['failed'])) { ?>
            Swal.fire({
                title:  "<?= addslashes($_SESSION['failed']); ?>",
                icon: "error",
                confirmButtonColor: "#2E5B7A"
            });
        <?php unset($_SESSION['failed']); } ?>
        </script>

</body>
</html>