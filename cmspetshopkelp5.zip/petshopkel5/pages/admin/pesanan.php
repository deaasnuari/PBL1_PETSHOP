<!DOCTYPE html>
<html lang="en">
<?php
//nama file: pesanan.php
//deskripsi: menampilkan pesanan yang telah dibuat oleh user
//dibut oleh: [front-end hamdan azmi[3312411004]]
//tgl dibuat: 9/12-28/12
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Produk</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap/bootstrap.min.css">
    <!-- costume styling -->
    <style>
        #sidebar.toggled {
            margin-left: -20vw;
        }

        #main-content.toggled {
            margin-left: 0;
        }

        #sidebar,
        #main-content {
            transition: all .3s ease;
        }

        a {
            text-decoration: none;
            color: black;
        }

        .link {
            border-bottom: 2px solid transparent;
            padding: 1rem 0 1rem 1rem;
            transition: .2s ease;
            border-bottom-left-radius: 12px;
        }

        .link:hover {
            padding-left: 1.5rem;
        }

        .link:last-child {
            border: none;
        }

        .active {
            border-bottom: 2px solid #2E5B7A;
            padding-left: 1.5rem;
            font-weight: bold;
            color: #2E5B7A;
        }

        thead th {
            text-align: center;
            vertical-align: middle;
            text-transform: capitalize;
        }

        tbody>tr>td {
            text-align: center;
            vertical-align: middle;
            height: 3.5rem;
        }

        .action>a {
            /* color: white; */
            padding: 5px 1rem;
            font-size: .8rem;
            border-radius: 5px;
            text-transform: capitalize;
        }

        .costume-shadow {
            box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
        }
    </style>
    <!-- costume styling end -->
</head>

<body style="background-color: #eeeeee;">
    <!-- header -->
    <div class="container-fluid position-sticky top-0" style="height: 14vh; z-index: 2;">
        <div class="row header h-100" style="background-color: #2E5B7A;">
            <div class="d-flex align-items-center gap-2 text-light">
                <img src="../../assets/images/miawoof-logo.jpg" style="width: 4rem" ; class="rounded-circle py-2">
                <span class="fw-bold fs-3">MiaWoof Petshop</span>
            </div>
        </div>
    </div>
    <!-- header end -->
    <div class="container-fluid p-0">
        <div class="d-flex p-0">
            <!-- sidebar -->
            <nav id="sidebar" class="sidebar border d-flex flex-column bg-light position-sticky"
                style="width: 20vw; height: calc(100vh - 14vh); top: 14vh; z-index: 2;">
                <div class="text-center m-3 mt-5">
                    <img src="../..//assets/icons/user.svg" alt="MiaWoof Petshop Logo" style="width: 80px;"
                        class="border border-dark rounded-circle">
                    <p class="fs-5 fw-bold m-0">Admin</p>
                </div>
                <a href="index.php" class="link">Dashboard</a>
                <a href="product_dashboard.php" class="link">Produk</a>
                <a href="pesanan.php" class="link active">Pesanan</a>
                <a href="grooming_dashboard.php" class="link">Grooming</a>
                <a href="user_dashboard.php" class="link">Data User</a>
                <a href="../logout.php" class="link mt-auto d-flex gap-2">
                    <img src="../../assets/icons/log-out.svg" width="18px" alt="">Logout
                </a>
            </nav>
            <!-- sidebar end -->

            <!-- main -->
            <div id="main-content" class="container-fluid p-0">

                <!-- main header -->
                <nav class="border-bottom p-4 bg-light position-sticky" style="top: 14vh; z-index: 2;">
                    <span class="fw-bold fs-4 d-flex gap-3"><img id="toggle-sidebar" role="button"
                            src="../../assets/icons/menu.svg" alt="">Pesanan</span>
                </nav>
                <!-- main header end -->

                <!-- main content -->
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-evenly flex-row-reverse"
                        style="height: calc(100vh - 28vh);">
                        <a href="booking.php"
                            class="card bg-light col-3 h-75 d-flex align-items-center justify-content-center costume-shadow">
                            <i>
                                <svg xmlns="http://www.w3.org/2000/svg" width="140" viewBox="0 0 180 163" fill="none">
                                    <path
                                        d="M5.33334 138.75V48.104C5.33334 36.7163 10.351 25.7949 19.2824 17.7426C28.2138 9.69026 40.3274 5.1665 52.9583 5.1665H127.042C133.296 5.1665 139.489 6.27712 145.267 8.43493C151.045 10.5927 156.295 13.7555 160.718 17.7426C165.14 21.7297 168.648 26.4631 171.041 31.6725C173.435 36.882 174.667 42.4654 174.667 48.104V114.896C174.667 120.534 173.435 126.118 171.041 131.327C168.648 136.537 165.14 141.27 160.718 145.257C156.295 149.244 151.045 152.407 145.267 154.565C139.489 156.723 133.296 157.833 127.042 157.833H26.5C20.8863 157.833 15.5024 155.823 11.5329 152.244C7.5634 148.665 5.33334 143.811 5.33334 138.75Z"
                                        stroke="#2E5B7A" stroke-width="10" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                    <path
                                        d="M47.6667 81.4997H84.7084C90.3221 81.4997 95.7059 83.5102 99.6754 87.0891C103.645 90.6679 105.875 95.5218 105.875 100.583C105.875 105.644 103.645 110.498 99.6754 114.077C95.7059 117.656 90.3221 119.666 84.7084 119.666H47.6667V52.8747C47.6667 50.3441 48.7817 47.9171 50.7665 46.1277C52.7512 44.3383 55.4431 43.333 58.25 43.333H74.125C79.7388 43.333 85.1226 45.3436 89.0921 48.9224C93.0616 52.5012 95.2917 57.3551 95.2917 62.4163C95.2917 67.4776 93.0616 72.3315 89.0921 75.9103C85.1226 79.4891 79.7388 81.4997 74.125 81.4997H58.25M132.333 119.666H132.439"
                                        stroke="#2E5B7A" stroke-width="10" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </i>
                            <br>
                            <p class="fw-bold fs-5">Booking grooming</p>
                        </a>
                        <a href="pesanan_produk.php"
                            class="card bg-light col-3 h-75 d-flex align-items-center justify-content-center costume-shadow">
                            <i>
                                <svg xmlns="http://www.w3.org/2000/svg" width="140" height="189" viewBox="0 0 200 189"
                                    fill="none">
                                    <path
                                        d="M100 112.282L133.975 92.0873L100 71.9087V112.282ZM30.1334 158.671C26.2945 158.671 23.0917 157.464 20.525 155.052C17.9584 152.639 16.6722 149.628 16.6667 146.02V74.3135H25V146.02C25 147.221 25.5334 148.325 26.6 149.333C27.6667 150.341 28.8417 150.843 30.125 150.837H154.167V158.671H30.1334ZM55.1334 135.171C51.2945 135.171 48.0917 133.964 45.525 131.552C42.9584 129.139 41.6722 126.128 41.6667 122.52V49.004H85.9V36.6508C85.9 33.0475 87.1834 30.0395 89.75 27.6268C92.3167 25.2142 95.5195 24.0052 99.3584 24H125.642C129.475 24 132.678 25.2089 135.25 27.6268C137.822 30.0447 139.106 33.0527 139.1 36.6508V49.004H183.333V122.52C183.333 126.123 182.05 129.134 179.483 131.552C176.917 133.97 173.714 135.176 169.875 135.171H55.1334ZM94.2334 49.004H130.767V36.6508C130.767 35.4497 130.233 34.3452 129.167 33.3373C128.1 32.3294 126.925 31.8281 125.642 31.8333H99.3584C98.0806 31.8333 96.9056 32.3347 95.8334 33.3373C94.7611 34.34 94.2278 35.4445 94.2334 36.6508V49.004Z"
                                        fill="#2E5B7A" />
                                </svg>
                            </i>
                            <br>
                            <p class="fw-bold fs-5">Pesanan Produk</p>
                        </a>
                    </div>
                </div>
                <!-- main content end -->


            </div>
            <!-- main end -->
        </div>
</body>
</div>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/script.js"></script>
<script>
    adminSidebarToggle();
</script>

</body>

</html>