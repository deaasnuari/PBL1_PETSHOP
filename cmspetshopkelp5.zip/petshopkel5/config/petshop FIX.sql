-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Des 2024 pada 14.16
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petshop`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `booking`
--

CREATE TABLE `booking` (
  `id_booking` int(11) NOT NULL,
  `id_paket` int(11) NOT NULL,
  `id_costumer` int(11) NOT NULL,
  `tgl` varchar(50) NOT NULL,
  `bulan` varchar(50) NOT NULL,
  `waktu` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `booking`
--

INSERT INTO `booking` (`id_booking`, `id_paket`, `id_costumer`, `tgl`, `bulan`, `waktu`, `status`) VALUES
(10, 7, 9, '23', '07', '14.00', 'menunggu konfirmasi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `paket_grooming`
--

CREATE TABLE `paket_grooming` (
  `id_paket` int(11) NOT NULL,
  `nama_paket` varchar(100) DEFAULT NULL,
  `jenis_hewan` varchar(50) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `keterangan_grooming` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `paket_grooming`
--

INSERT INTO `paket_grooming` (`id_paket`, `nama_paket`, `jenis_hewan`, `harga`, `keterangan_grooming`) VALUES
(1, 'reguler', 'kucing', 40000, 'Mandi, Pengeringan, Perawatan kuku, Perawatan Telinga'),
(3, 'reguler', 'anjing', 50000, 'Mandi, Pengeringan, Perawatan kuku, Perawatan Telinga'),
(5, 'premium', 'kucing', 50000, 'Mandi, Pengeringan Bulu, Perawatan kuku, Perawatan, Telinga, Perawatan Mata, Pangkas Bulu'),
(7, 'premium', 'anjing', 60000, 'Mandi, Pengeringan Bulu, Perawatan kuku, Perawatan, Telinga, Perawatan Mata, Pangkas Bulu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `id_pesanan` int(11) NOT NULL,
  `id_produk` int(11) DEFAULT NULL,
  `id_pembeli` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `tgl_pesanan` date DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `id_produk`, `id_pembeli`, `jumlah`, `total`, `tgl_pesanan`, `status`) VALUES
(23, 1, 9, 16, 3200000, '2024-12-26', 'menunggu pembayaran'),
(24, 1, 9, 6, 1200000, '2024-12-26', 'menunggu pembayaran');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `tgl_dibuat` date DEFAULT NULL,
  `tgl_expired` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `nama`, `kategori`, `stock`, `harga`, `gambar`, `tgl_dibuat`, `tgl_expired`) VALUES
(1, 'whiskas 25Kg', 'kucing', -10, 200000, NULL, '2024-12-02', '2024-12-31'),
(2, 'royal canin 2Kg', 'kucing', 25, 450000, NULL, '2024-12-16', '2024-12-17'),
(3, 'contoh makanan anjing 5Kg', 'anjing', -1, 200000, NULL, '2024-12-10', '2024-12-12');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `no_hp` varchar(50) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `email`, `no_hp`, `alamat`, `role`) VALUES
(1, 'admin1', 'admin123', 'Christian Marcelino', NULL, NULL, NULL, 'admin'),
(9, 'hamdan_Ajah', '123', 'hamdan azmi', 'hamdanAjah@gmail.com', '089665314602', 'Perum. Muka Kuning Jalan Soekarno 62 Jakarta', 'costumer');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id_booking`),
  ADD KEY `id_paket` (`id_paket`),
  ADD KEY `id_pembeli` (`id_costumer`);

--
-- Indeks untuk tabel `paket_grooming`
--
ALTER TABLE `paket_grooming`
  ADD PRIMARY KEY (`id_paket`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id_pesanan`),
  ADD KEY `pesanan_ibfk_1` (`id_produk`),
  ADD KEY `pesanan_ibfk_2` (`id_pembeli`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `booking`
--
ALTER TABLE `booking`
  MODIFY `id_booking` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `paket_grooming`
--
ALTER TABLE `paket_grooming`
  MODIFY `id_paket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id_pesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`id_paket`) REFERENCES `paket_grooming` (`id_paket`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`id_costumer`) REFERENCES `users` (`id`);

--
-- Ketidakleluasaan untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD CONSTRAINT `pesanan_ibfk_1` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pesanan_ibfk_2` FOREIGN KEY (`id_pembeli`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
