<?php
// koneksi.php
// file ini digunakan untuk menghubungkan aplikasi ke database
// dibuat oleh christian marcelino[3312411008]
// tgl dibuat: 9/12-28/12

$host = "localhost";
$username = "root";
$password = "";
$database = "petshop";

try {
    $conn = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Koneksi berhasil!";
    
} catch (PDOException $e) {
    echo "Koneksi gagal: " . $e->getMessage();
}
?>
